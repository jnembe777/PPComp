// ppv_core.hpp — PPV Codec C++ Core
// Sprint C1: BitWriter/BitReader (64-bit buffer)
// Sprint C2: Combinatorics (precomputed C(n,k), ranking/unranking via POPCNT)
// Sprint C3: Representations R1-R4 encode/decode
#pragma once

#include <cstdint>
#include <cstring>
#include <vector>
#include <array>
#include <algorithm>
#include <bit>       // C++20 popcount, countl_zero
#include <immintrin.h> // POPCNT, BMI2, AVX2

namespace ppv {

// ═══════════════════════════════════════════════════════════
//  BITSTREAM — 64-bit buffered I/O
// ═══════════════════════════════════════════════════════════

class BitWriter {
    std::vector<uint8_t> buf_;
    uint64_t accum_ = 0;    // 64-bit accumulator
    int bits_in_ = 0;       // bits pending in accumulator
    size_t total_bits_ = 0;

    void flush_byte() {
        buf_.push_back(static_cast<uint8_t>(accum_ >> 56));
        accum_ <<= 8;
        bits_in_ -= 8;
    }

public:
    // Write up to 57 bits at once (safe with 64-bit accum)
    void write_bits(uint64_t value, int n) {
        total_bits_ += n;
        accum_ |= (value << (64 - bits_in_ - n));
        bits_in_ += n;
        while (bits_in_ >= 8) flush_byte();
    }

    void write_bool(bool b) { write_bits(b ? 1 : 0, 1); }

    // Elias gamma: encode positive integer n
    // Format: (floor(log2(n))) zeros, then n in binary
    int write_elias_gamma(uint32_t n) {
        if (n == 0) n = 1;
        int len = 32 - __builtin_clz(n);  // floor(log2(n)) + 1
        int zeros = len - 1;
        write_bits(0, zeros);
        write_bits(n, len);
        return zeros + len;
    }

    void write_uint16(uint16_t v) { write_bits(v, 16); }

    // Flush remaining bits (pad to byte boundary)
    std::vector<uint8_t> finish() {
        while (bits_in_ > 0) flush_byte();
        return buf_;
    }

    size_t total_bits() const { return total_bits_; }
    const std::vector<uint8_t>& data() const { return buf_; }
};


class BitReader {
    const uint8_t* data_;
    size_t size_;
    uint64_t accum_ = 0;
    int bits_in_ = 0;
    size_t byte_pos_ = 0;

    void refill() {
        while (bits_in_ <= 56 && byte_pos_ < size_) {
            accum_ |= static_cast<uint64_t>(data_[byte_pos_++])
                       << (56 - bits_in_);
            bits_in_ += 8;
        }
    }

public:
    BitReader(const uint8_t* data, size_t size)
        : data_(data), size_(size) { refill(); }

    BitReader(const std::vector<uint8_t>& vec)
        : BitReader(vec.data(), vec.size()) {}

    uint64_t read_bits(int n) {
        refill();
        uint64_t val = accum_ >> (64 - n);
        accum_ <<= n;
        bits_in_ -= n;
        return val;
    }

    bool read_bool() { return read_bits(1) != 0; }

    uint32_t read_elias_gamma() {
        int zeros = 0;
        while (read_bits(1) == 0) zeros++;
        if (zeros == 0) return 1;
        uint32_t val = (1u << zeros) | static_cast<uint32_t>(read_bits(zeros));
        return val;
    }

    uint16_t read_uint16() { return static_cast<uint16_t>(read_bits(16)); }
};


// ═══════════════════════════════════════════════════════════
//  COMBINATORICS — Precomputed C(n,k) + ranking/unranking
// ═══════════════════════════════════════════════════════════

// Precompute C(n,k) for n <= 128, k <= 128
// Using Pascal's triangle, stored in a flat array
static constexpr int COMB_MAX = 129;

class CombTable {
    // C(n,k) — use uint64_t, capped at UINT64_MAX for overflow
    uint64_t table_[COMB_MAX][COMB_MAX];

public:
    CombTable() {
        std::memset(table_, 0, sizeof(table_));
        for (int n = 0; n < COMB_MAX; n++) {
            table_[n][0] = 1;
            for (int k = 1; k <= n; k++) {
                uint64_t a = table_[n-1][k-1];
                uint64_t b = table_[n-1][k];
                // Saturating add
                table_[n][k] = (a > UINT64_MAX - b) ? UINT64_MAX : a + b;
            }
        }
    }

    uint64_t C(int n, int k) const {
        if (k < 0 || k > n || n >= COMB_MAX) return 0;
        return table_[n][k];
    }

    // Bits needed for C(n,k)
    int bits_for(int n, int k) const {
        uint64_t c = C(n, k);
        if (c <= 1) return 0;
        return 64 - __builtin_clzll(c - 1);  // ceil(log2(c))
    }
};

// Global singleton
inline const CombTable& comb_table() {
    static const CombTable instance;
    return instance;
}


// ═══════════════════════════════════════════════════════════
//  BOOLEAN VECTOR — 64/128 bit with POPCNT operations
// ═══════════════════════════════════════════════════════════

// For r <= 64, the boolean vector fits in a single uint64_t
// bit 63 = t=0, bit 62 = t=1, ..., bit (64-r) = t=r-1

struct BoolVec64 {
    uint64_t bits;
    int r;        // effective length

    int popcount() const { return std::popcount(bits); }
    int n_jumps() const { return popcount(); }

    // Get bit at position t (0-indexed from MSB)
    bool get(int t) const {
        return (bits >> (63 - t)) & 1;
    }

    // Set bit at position t
    void set(int t) {
        bits |= (1ULL << (63 - t));
    }

    // First set bit position (first jump time)
    int first_set() const {
        return __builtin_clzll(bits);
    }

    // Iterate over set bits (jump times)
    // Calls fn(t) for each t where bit is set
    template<typename Fn>
    void for_each_set(Fn fn) const {
        uint64_t tmp = bits;
        while (tmp) {
            int pos = __builtin_clzll(tmp);
            fn(pos);
            tmp &= ~(1ULL << (63 - pos));
        }
    }

    // ── Combinatorial ranking (co-lex combinadic) ──────
    // Matches Python: s = sum C(p_i, i+1) for sorted positions p_i

    uint64_t rank(const CombTable& ct) const {
        // Collect positions of set bits (ascending order)
        uint64_t index = 0;
        int rank_k = 0;  // 0-based rank among set bits

        for (int t = 0; t < r; t++) {
            if (get(t)) {
                // Python: s += binomial(p, i+1) where i is 0-based
                index += ct.C(t, rank_k + 1);
                rank_k++;
            }
        }
        return index;
    }

    static BoolVec64 unrank(uint64_t s, int r, int n,
                            const CombTable& ct) {
        // Python: k=n, for i in range(r-1, -1, -1): if C(i,k)<=s: ...
        BoolVec64 bv{0, r};
        int k = n;

        for (int i = r - 1; i >= 0 && k > 0; i--) {
            uint64_t c = ct.C(i, k);
            if (c <= s) {
                s -= c;
                bv.set(i);
                k--;
            }
        }
        return bv;
    }
};


// ═══════════════════════════════════════════════════════════
//  PIXEL SEQUENCE — compact representation of a pixel's
//  temporal evolution as jump vector + colors
// ═══════════════════════════════════════════════════════════

struct PixelProcess {
    BoolVec64 jumps;         // boolean vector of jump times
    std::vector<uint8_t> colors;  // colors at each jump
    int n_jumps;

    // Build from raw sequence
    static PixelProcess from_sequence(const uint8_t* seq, int r) {
        PixelProcess pp;
        pp.jumps = {0, r};
        pp.n_jumps = 0;

        pp.jumps.set(0);
        pp.colors.push_back(seq[0]);
        pp.n_jumps = 1;

        for (int t = 1; t < r; t++) {
            if (seq[t] != seq[t-1]) {
                pp.jumps.set(t);
                pp.colors.push_back(seq[t]);
                pp.n_jumps++;
            }
        }
        return pp;
    }

    // Reconstruct sequence
    void to_sequence(uint8_t* out, int r) const {
        int ci = 0;
        uint8_t cur = 0;
        for (int t = 0; t < r; t++) {
            if (jumps.get(t)) {
                cur = colors[ci++];
            }
            out[t] = cur;
        }
    }

    // Encode as R4: Elias(n) + rank(jumps) + colors
    void encode_R4(BitWriter& w, int r, int color_bits,
                   const CombTable& ct) const {
        w.write_elias_gamma(n_jumps);
        int s_bits = ct.bits_for(r, n_jumps);
        if (s_bits > 0) {
            w.write_bits(jumps.rank(ct), s_bits);
        }
        for (uint8_t c : colors) {
            w.write_bits(c, color_bits);
        }
    }

    // Decode R4
    static PixelProcess decode_R4(BitReader& rd, int r, int color_bits,
                                  const CombTable& ct) {
        PixelProcess pp;
        pp.n_jumps = rd.read_elias_gamma();
        int s_bits = ct.bits_for(r, pp.n_jumps);
        uint64_t s_idx = s_bits > 0 ? rd.read_bits(s_bits) : 0;
        pp.jumps = BoolVec64::unrank(s_idx, r, pp.n_jumps, ct);
        pp.colors.resize(pp.n_jumps);
        for (int i = 0; i < pp.n_jumps; i++) {
            pp.colors[i] = static_cast<uint8_t>(rd.read_bits(color_bits));
        }
        return pp;
    }
};


// ═══════════════════════════════════════════════════════════
//  BLOCK ANALYSIS — fast metrics via POPCNT
// ═══════════════════════════════════════════════════════════

struct BlockMetrics {
    int m;                  // distinct colors
    float mean_jumps;
    float jump_pattern_dominance;
    float change_rate;

    // NCD bitmap: 4 × uint64_t = 256 bits for tracking distinct colors
    static int count_distinct_colors(const uint8_t* block, int size) {
        uint64_t bitmap[4] = {0, 0, 0, 0};
        for (int i = 0; i < size; i++) {
            uint8_t c = block[i];
            bitmap[c >> 6] |= (1ULL << (c & 63));
        }
        return std::popcount(bitmap[0]) + std::popcount(bitmap[1])
             + std::popcount(bitmap[2]) + std::popcount(bitmap[3]);
    }
};

} // namespace ppv
