// ppv_decoder.hpp — PPV Video Decoder C++
// Sprint C6: Complete grayscale decoding pipeline
#pragma once
#include "ppv_core.hpp"
#include "ppv_huffman.hpp"
#include "ppv_encoder.hpp"
#include <vector>
#include <cstring>
#include <fstream>
#include <stdexcept>
#include <algorithm>

namespace ppv {

inline void invert_prediction_frame_local(
    const uint8_t* residual, uint8_t* frame, int nl, int nc, int mode
) {
    if (mode == PRED_BYPASS) {
        std::memcpy(frame, residual, nl * nc); return;
    }
    for (int i = 0; i < nl; i++) {
        for (int j = 0; j < nc; j++) {
            int left = (j > 0) ? frame[i*nc+j-1] : 0;
            int top  = (i > 0) ? frame[(i-1)*nc+j] : 0;
            int tl   = (i > 0 && j > 0) ? frame[(i-1)*nc+j-1] : 0;
            int pred = 0;
            switch (mode) {
                case PRED_LEFT: pred = left; break;
                case PRED_TOP:  pred = top; break;
                case PRED_DC:   pred = (left + top) >> 1; break;
                case PRED_PAETH: {
                    int p = left + top - tl;
                    int pa = std::abs(p-left), pb = std::abs(p-top), pc = std::abs(p-tl);
                    pred = (pa<=pb && pa<=pc) ? left : (pb<=pc) ? top : tl;
                    break;
                }
                case PRED_MED: {
                    int mn = std::min(left,top), mx = std::max(left,top);
                    pred = (tl>=mx) ? mn : (tl<=mn) ? mx : left+top-tl;
                    break;
                }
            }
            frame[i*nc+j] = (residual[i*nc+j] + pred) & 0xFF;
        }
    }
}

struct DecodeResult {
    int nl, nc, r, fps, color_bits;
    std::vector<uint8_t> frames;
    int mono_count = 0, pp_count = 0;
};

class PPVDecoder {
public:
    DecodeResult decode(const char* path) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f.is_open()) throw std::runtime_error("Cannot open file");
        size_t fsize = f.tellg(); f.seekg(0);
        std::vector<uint8_t> raw(fsize);
        f.read((char*)raw.data(), fsize); f.close();

        if (fsize < PPV_HEADER_SIZE) throw std::runtime_error("File too small");
        auto be16 = [](const uint8_t* p) -> uint16_t { return ((uint16_t)p[0]<<8)|p[1]; };
        const uint8_t* h = raw.data();
        if (h[0]!='P'||h[1]!='P'||h[2]!='V'||h[3]!='1')
            throw std::runtime_error("Invalid magic");

        DecodeResult res;
        res.nl = be16(h+6); res.nc = be16(h+8); res.r = be16(h+10);
        res.color_bits = h[12]; res.fps = h[13];
        int gop_size = be16(h+14), nb_gops = be16(h+16);
        int nl = res.nl, nc = res.nc, r_total = res.r;
        res.frames.resize((size_t)r_total * nl * nc, 0);

        const auto& ct = comb_table();
        BitReader reader(raw.data() + PPV_HEADER_SIZE, fsize - PPV_HEADER_SIZE);

        for (int g = 0; g < nb_gops; g++) {
            int gop_idx = reader.read_uint16();
            int gop_r = reader.read_uint16();
            int nb_planes = reader.read_bits(2);
            int block_size = reader.read_bits(8);
            int t_offset = g * gop_size;

            for (int pl = 0; pl < nb_planes; pl++) {
                int temporal_mode = reader.read_bits(2);
                int pred_bs = 8;
                int nb_pi = (nl+pred_bs-1)/pred_bs, nb_pj = (nc+pred_bs-1)/pred_bs;
                bool has_pred = reader.read_bool();
                std::vector<int> mode_map(nb_pi*nb_pj, 0);
                if (has_pred)
                    for (int i = 0; i < nb_pi*nb_pj; i++)
                        mode_map[i] = reader.read_bits(3);

                bool has_adaptive = reader.read_bool();
                struct BR { int i0,i1,j0,j1; };
                std::vector<BR> blocks;
                if (has_adaptive) {
                    int nsi=(nl+15)/16, nsj=(nc+15)/16;
                    std::vector<bool> sm(nsi*nsj);
                    for (int i=0;i<nsi*nsj;i++) sm[i]=reader.read_bool();
                    for (int si=0;si<nsi;si++) for (int sj=0;sj<nsj;sj++) {
                        int i0=si*16,i1=std::min(i0+16,nl),j0=sj*16,j1=std::min(j0+16,nc);
                        if (sm[si*nsj+sj]) {
                            int mi=i0+std::min(8,i1-i0), mj=j0+std::min(8,j1-j0);
                            if(mi>i0&&mj>j0) blocks.push_back({i0,mi,j0,mj});
                            if(mi>i0&&j1>mj) blocks.push_back({i0,mi,mj,j1});
                            if(i1>mi&&mj>j0) blocks.push_back({mi,i1,j0,mj});
                            if(i1>mi&&j1>mj) blocks.push_back({mi,i1,mj,j1});
                        } else blocks.push_back({i0,i1,j0,j1});
                    }
                } else {
                    for(int bi=0;bi<nl;bi+=block_size)
                        for(int bj=0;bj<nc;bj+=block_size)
                            blocks.push_back({bi,std::min(bi+block_size,nl),
                                              bj,std::min(bj+block_size,nc)});
                }

                bool has_cm_huff = reader.read_bool();
                HuffmanTable cm_ht;
                if (has_cm_huff) cm_ht = HuffmanTable::read_table(reader, 7);

                std::vector<uint8_t> rbuf((size_t)gop_r*nl*nc, 0);

                for (auto& blk : blocks) {
                    int bh=blk.i1-blk.i0, bw=blk.j1-blk.j0, npx=bh*bw;
                    bool has_pal = reader.read_bool();
                    int eff_bits = res.color_bits;
                    int pal_m = 0; uint8_t pal_c[256]={};
                    if (has_pal) {
                        pal_m = reader.read_elias_gamma();
                        for(int i=0;i<pal_m;i++) pal_c[i]=(uint8_t)reader.read_bits(res.color_bits);
                        eff_bits = (pal_m<=1)?1:(32-__builtin_clz(pal_m-1));
                        if(pal_m==1) eff_bits=1;
                    }
                    uint8_t cm = has_cm_huff ? cm_ht.decode_symbol(reader)
                                             : (uint8_t)reader.read_bits(7);
                    int proc = (cm>>5)&3;

                    if (proc == PROC_MONO) {
                        uint8_t c = (uint8_t)reader.read_bits(eff_bits);
                        if (has_pal && c<pal_m) c = pal_c[c];
                        for(int t=0;t<gop_r;t++)
                            for(int i=blk.i0;i<blk.i1;i++)
                                for(int j=blk.j0;j<blk.j1;j++)
                                    rbuf[t*nl*nc+i*nc+j]=c;
                        res.mono_count += npx;
                    } else {
                        bool has_huff = reader.read_bool();
                        HuffmanTable bht;
                        if(has_huff) bht = HuffmanTable::read_table(reader, eff_bits);

                        for(int pi=0;pi<bh;pi++) for(int pj=0;pj<bw;pj++) {
                            int nj = reader.read_elias_gamma();
                            int sb = ct.bits_for(gop_r, nj);
                            uint64_t si = sb>0 ? reader.read_bits(sb) : 0;
                            auto bv = BoolVec64::unrank(si, gop_r, nj, ct);
                            uint8_t cols[128];
                            for(int k=0;k<nj;k++)
                                cols[k] = has_huff ? bht.decode_symbol(reader)
                                                   : (uint8_t)reader.read_bits(eff_bits);
                            if (has_pal)
                                for(int k=0;k<nj;k++)
                                    if(cols[k]<pal_m) cols[k]=pal_c[cols[k]];
                            int ci=0; uint8_t cur=0;
                            for(int t=0;t<gop_r;t++) {
                                if(bv.get(t)) cur=cols[ci++];
                                rbuf[t*nl*nc+(blk.i0+pi)*nc+(blk.j0+pj)]=cur;
                            }
                        }
                        res.pp_count += npx;
                    }
                }

                // Invert prediction per 8x8 block
                if (has_pred) {
                    for(int t=0;t<gop_r;t++) {
                        int midx=0;
                        for(int bi=0;bi<nl;bi+=pred_bs) {
                            for(int bj=0;bj<nc;bj+=pred_bs) {
                                int bh2=std::min(pred_bs,nl-bi), bw2=std::min(pred_bs,nc-bj);
                                int mode=mode_map[midx++];
                                uint8_t br2[64], bf[64];
                                for(int i=0;i<bh2;i++)
                                    for(int j=0;j<bw2;j++)
                                        br2[i*bw2+j]=rbuf[t*nl*nc+(bi+i)*nc+(bj+j)];
                                invert_prediction_frame_local(br2,bf,bh2,bw2,mode);
                                for(int i=0;i<bh2;i++)
                                    for(int j=0;j<bw2;j++)
                                        rbuf[t*nl*nc+(bi+i)*nc+(bj+j)]=bf[i*bw2+j];
                            }
                        }
                    }
                }

                // Invert temporal
                if (temporal_mode == 1) {
                    for(int t=1;t<gop_r;t++) {
                        uint8_t* cur=rbuf.data()+(size_t)t*nl*nc;
                        const uint8_t* prev=rbuf.data()+(size_t)(t-1)*nl*nc;
                        for(int p=0;p<nl*nc;p++) cur[p]^=prev[p];
                    }
                } else if (temporal_mode == 2) {
                    for(int t=1;t<gop_r;t++) {
                        uint8_t* cur=rbuf.data()+(size_t)t*nl*nc;
                        const uint8_t* prev=rbuf.data()+(size_t)(t-1)*nl*nc;
                        for(int p=0;p<nl*nc;p++) cur[p]=(cur[p]+prev[p])&0xFF;
                    }
                }

                for(int t=0;t<gop_r;t++) {
                    int ta=t_offset+t;
                    if(ta<r_total)
                        std::memcpy(res.frames.data()+(size_t)ta*nl*nc,
                                    rbuf.data()+(size_t)t*nl*nc, nl*nc);
                }
            }
        }
        return res;
    }
};

} // namespace ppv
