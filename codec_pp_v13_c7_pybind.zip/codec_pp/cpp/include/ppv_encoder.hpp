// ppv_encoder.hpp — PPV Video Encoder C++
// Sprint C5: Complete grayscale encoding pipeline
//   Header → GOP → Temporal delta → Paeth prediction → Blocks 16x16
//   → Palette → MDL classification → R4 + Huffman → .ppv file
#pragma once

#include "ppv_core.hpp"
#include "ppv_huffman.hpp"
#include <vector>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <fstream>

namespace ppv {

// ═══════════════════════════════════════════════════════════
//  FORMAT CONSTANTS (matches Python format.py)
// ═══════════════════════════════════════════════════════════

static constexpr uint8_t PPV_MAGIC[4] = {'P','P','V','1'};
static constexpr uint8_t PPV_VERSION = 0x01;
static constexpr int PPV_HEADER_SIZE = 24;

// Code Methode fields
static constexpr int PROC_MONO = 0, PROC_PP = 1, PROC_SPATIAL = 2, PROC_MARKOV = 3;
static constexpr int REP_R1 = 0, REP_R2 = 1, REP_R3 = 2, REP_R4 = 3;
static constexpr int COMP_NONE = 0, COMP_HUFFMAN = 1;

inline uint8_t make_code_methode(int proc, int rep, int comp, int col) {
    return ((proc & 3) << 5) | ((rep & 3) << 3) | ((comp & 3) << 1) | (col & 1);
}

// ═══════════════════════════════════════════════════════════
//  PREDICTION — Paeth (mode 4), applied per-frame
// ═══════════════════════════════════════════════════════════

// Mode constants
static constexpr int PRED_BYPASS = 0, PRED_LEFT = 1, PRED_TOP = 2;
static constexpr int PRED_DC = 3, PRED_PAETH = 4, PRED_MED = 5;
static constexpr int NUM_PRED_MODES = 6;

// Apply prediction to one frame, return residuals
inline void apply_prediction_frame(
    const uint8_t* frame, uint8_t* residual, int nl, int nc, int mode
) {
    if (mode == PRED_BYPASS) {
        std::memcpy(residual, frame, nl * nc);
        return;
    }
    const auto F = [&](int i, int j) -> int {
        return (i >= 0 && i < nl && j >= 0 && j < nc) ? frame[i*nc+j] : 0;
    };
    for (int i = 0; i < nl; i++) {
        for (int j = 0; j < nc; j++) {
            int left = (j > 0) ? frame[i*nc+j-1] : 0;
            int top  = (i > 0) ? frame[(i-1)*nc+j] : 0;
            int tl   = (i > 0 && j > 0) ? frame[(i-1)*nc+j-1] : 0;
            int pred = 0;
            switch (mode) {
                case PRED_LEFT: pred = left; break;
                case PRED_TOP:  pred = top; break;
                case PRED_DC:   pred = (left + top) >> 1; break;
                case PRED_PAETH: {
                    int p = left + top - tl;
                    int pa = std::abs(p - left);
                    int pb = std::abs(p - top);
                    int pc = std::abs(p - tl);
                    pred = (pa <= pb && pa <= pc) ? left : (pb <= pc) ? top : tl;
                    break;
                }
                case PRED_MED: {
                    int mn = std::min(left, top);
                    int mx = std::max(left, top);
                    pred = (tl >= mx) ? mn : (tl <= mn) ? mx : left + top - tl;
                    break;
                }
            }
            residual[i*nc+j] = (frame[i*nc+j] - pred) & 0xFF;
        }
    }
}

// Estimate entropy of residuals (simple: count distinct + variance proxy)
inline float estimate_residual_entropy(const uint8_t* data, int size) {
    int freq[256] = {};
    for (int i = 0; i < size; i++) freq[data[i]]++;
    float entropy = 0;
    for (int i = 0; i < 256; i++) {
        if (freq[i] > 0) {
            float p = (float)freq[i] / size;
            entropy -= p * std::log2(p);
        }
    }
    return entropy;
}

// Choose best prediction mode for a block region
inline int choose_best_mode(
    const uint8_t* plane, int nl, int nc, int r,
    int bi0, int bi1, int bj0, int bj1
) {
    int bh = bi1 - bi0, bw = bj1 - bj0;
    int block_size = bh * bw;
    std::vector<uint8_t> residual(block_size);

    float best_entropy = 1e9;
    int best_mode = PRED_BYPASS;

    for (int mode = 0; mode < NUM_PRED_MODES; mode++) {
        float total_entropy = 0;
        // Test on first frame only (fast heuristic)
        const uint8_t* frame = plane;  // frame 0
        // Extract block and apply prediction
        std::vector<uint8_t> block(bh * bw);
        for (int i = 0; i < bh; i++)
            for (int j = 0; j < bw; j++)
                block[i*bw+j] = frame[(bi0+i)*nc + (bj0+j)];

        // Build full frame for correct neighbor access
        // (simplified: use the block with border=0 assumption)
        apply_prediction_frame(block.data(), residual.data(), bh, bw, mode);
        total_entropy = estimate_residual_entropy(residual.data(), block_size);

        if (total_entropy < best_entropy) {
            best_entropy = total_entropy;
            best_mode = mode;
        }
    }
    return best_mode;
}

// ═══════════════════════════════════════════════════════════
//  PALETTE — count distinct colors, palette transform
// ═══════════════════════════════════════════════════════════

struct PaletteInfo {
    bool use_palette;
    int m;           // distinct colors
    int index_bits;  // ceil(log2(m))
    uint8_t colors[256];  // palette colors sorted
};

inline PaletteInfo analyze_palette(const uint8_t* block, int size) {
    PaletteInfo pi;
    pi.m = BlockMetrics::count_distinct_colors(block, size);
    pi.index_bits = (pi.m <= 1) ? 1 : (32 - __builtin_clz(pi.m - 1));
    if (pi.m == 1) pi.index_bits = 1;
    pi.use_palette = (pi.index_bits < 8 && pi.m <= 64);

    if (pi.use_palette) {
        // Collect sorted unique colors
        uint64_t bitmap[4] = {};
        for (int i = 0; i < size; i++)
            bitmap[block[i]>>6] |= (1ULL << (block[i] & 63));
        int ci = 0;
        for (int c = 0; c < 256 && ci < pi.m; c++)
            if (bitmap[c>>6] & (1ULL << (c & 63)))
                pi.colors[ci++] = c;
    }
    return pi;
}

inline void palette_transform(
    const uint8_t* in, uint8_t* out, int size, const PaletteInfo& pi
) {
    // Build reverse lookup
    uint8_t rev[256] = {};
    for (int i = 0; i < pi.m; i++) rev[pi.colors[i]] = i;
    for (int i = 0; i < size; i++) out[i] = rev[in[i]];
}

// ═══════════════════════════════════════════════════════════
//  BLOCK CLASSIFICATION — MDL (simplified: Mono vs PP/R4)
// ═══════════════════════════════════════════════════════════

struct BlockClassification {
    int proc_type;    // PROC_MONO or PROC_PP
    int best_rep;     // 1-4 (for PP)
    uint8_t mono_color;  // if mono
};

inline BlockClassification classify_block_mdl(
    const uint8_t* block_3d, int r, int bh, int bw, int eff_bits,
    const CombTable& ct
) {
    BlockClassification bc;
    int n_pixels = bh * bw;

    // Check per-pixel: all pixels must have n_jumps==1 AND same color
    bool is_mono = true;
    uint8_t mono_color = block_3d[0];  // pixel (0,0) at t=0

    for (int px = 0; px < n_pixels && is_mono; px++) {
        uint8_t first = block_3d[px];  // this pixel at t=0
        if (first != mono_color) { is_mono = false; break; }
        for (int t = 1; t < r; t++) {
            if (block_3d[t * n_pixels + px] != first) {
                is_mono = false; break;
            }
        }
    }

    if (is_mono) {
        bc.proc_type = PROC_MONO;
        bc.mono_color = mono_color;
        bc.best_rep = 0;
        return bc;
    }

    bc.proc_type = PROC_PP;
    bc.best_rep = 4;  // R4
    return bc;
}

// ═══════════════════════════════════════════════════════════
//  ENCODER — Complete pipeline
// ═══════════════════════════════════════════════════════════

struct EncodeStats {
    int nl, nc, r, fps;
    int gop_size, block_size;
    int nb_gops;
    size_t compressed_bytes;
    size_t raw_bytes;
    float compression_ratio;
    int mono_count;
    int pp_count;
    int rep_counts[5];  // [0]=unused, [1]=R1, [2]=R2, [3]=R3, [4]=R4
};

class PPVEncoder {
    int gop_size_;
    int block_size_;
    int temporal_mode_;  // 0=none, 1=XOR, 2=delta
    bool use_huffman_;

public:
    PPVEncoder(int gop_size = 64, int block_size = 16,
               int temporal_mode = 0, bool use_huffman = true)
        : gop_size_(gop_size), block_size_(block_size),
          temporal_mode_(temporal_mode), use_huffman_(use_huffman) {}

    // Auto-encode: try multiple temporal modes, keep best
    EncodeStats encode_auto(
        const uint8_t* M, int nl, int nc, int r_total,
        const char* output_path, int color_bits = 8, int fps = 30
    ) {
        EncodeStats best_stats = {};
        best_stats.compression_ratio = 0;

        std::string best_path;
        std::string base(output_path);

        for (int tm : {0, 2}) {  // try none and delta
            temporal_mode_ = tm;
            std::string tmp = base + (tm == 0 ? ".tmp0" : ".tmp2");
            auto stats = encode(M, nl, nc, r_total, tmp.c_str(), color_bits, fps);
            if (stats.compression_ratio > best_stats.compression_ratio) {
                best_stats = stats;
                best_path = tmp;
            } else {
                std::remove(tmp.c_str());
            }
        }

        // Rename best to output
        if (!best_path.empty()) {
            std::remove(output_path);
            std::rename(best_path.c_str(), output_path);
            // Clean other temp
            std::remove((base + ".tmp0").c_str());
            std::remove((base + ".tmp2").c_str());
        }

        return best_stats;
    }

    EncodeStats encode(
        const uint8_t* M, int nl, int nc, int r_total,
        const char* output_path, int color_bits = 8, int fps = 30
    ) {
        const auto& ct = comb_table();
        int bs = block_size_;
        int nb_gops = (r_total + gop_size_ - 1) / gop_size_;
        int col_flag = 0;  // grayscale
        int comp_flag = use_huffman_ ? COMP_HUFFMAN : COMP_NONE;

        EncodeStats stats = {};
        stats.nl = nl; stats.nc = nc; stats.r = r_total;
        stats.fps = fps; stats.gop_size = gop_size_;
        stats.block_size = bs; stats.nb_gops = nb_gops;
        stats.raw_bytes = (size_t)r_total * nl * nc;

        BitWriter body;

        // Temp buffers
        std::vector<uint8_t> gop_buf(gop_size_ * nl * nc);
        std::vector<uint8_t> pred_buf(gop_size_ * nl * nc);
        std::vector<uint8_t> block_buf(gop_size_ * bs * bs);

        for (int g = 0; g < nb_gops; g++) {
            int t0 = g * gop_size_;
            int t1 = std::min(t0 + gop_size_, r_total);
            int gop_r = t1 - t0;

            // GOP header
            body.write_uint16(g);
            body.write_uint16(gop_r);
            body.write_bits(1, 2);  // nb_planes = 1 (grayscale)
            body.write_bits(bs, 8);

            // Copy GOP data
            std::memcpy(gop_buf.data(), M + (size_t)t0 * nl * nc,
                        (size_t)gop_r * nl * nc);

            // ── Temporal preprocessing ────────────────
            body.write_bits(temporal_mode_, 2);

            if (temporal_mode_ == 1) {
                // XOR
                for (int t = gop_r - 1; t >= 1; t--) {
                    uint8_t* cur = gop_buf.data() + (size_t)t * nl * nc;
                    const uint8_t* prev = gop_buf.data() + (size_t)(t-1) * nl * nc;
                    for (int p = 0; p < nl * nc; p++)
                        cur[p] ^= prev[p];
                }
            } else if (temporal_mode_ == 2) {
                // Delta arithmetic
                for (int t = gop_r - 1; t >= 1; t--) {
                    uint8_t* cur = gop_buf.data() + (size_t)t * nl * nc;
                    const uint8_t* prev = gop_buf.data() + (size_t)(t-1) * nl * nc;
                    for (int p = 0; p < nl * nc; p++)
                        cur[p] = (cur[p] - prev[p]) & 0xFF;
                }
            }

            // ── Prediction (per 8x8 block, best mode selection) ──
            int pred_bs = 8;
            int nb_pi = (nl + pred_bs - 1) / pred_bs;
            int nb_pj = (nc + pred_bs - 1) / pred_bs;

            // Select best mode per block (like Python choose_best_mode_plane)
            std::vector<int> mode_map(nb_pi * nb_pj);
            {
                int midx = 0;
                for (int bi = 0; bi < nl; bi += pred_bs) {
                    for (int bj = 0; bj < nc; bj += pred_bs) {
                        int bh = std::min(pred_bs, nl - bi);
                        int bw = std::min(pred_bs, nc - bj);

                        float best_ent = 1e9f;
                        int best_mode = PRED_BYPASS;

                        for (int mode : {PRED_BYPASS, PRED_LEFT, PRED_PAETH}) {
                            // Test on frame 0 only (fast heuristic)
                            const uint8_t* frame0 = gop_buf.data();
                            uint8_t blk[64], res[64];
                            for (int i = 0; i < bh; i++)
                                for (int j = 0; j < bw; j++)
                                    blk[i*bw+j] = frame0[(bi+i)*nc+(bj+j)];
                            apply_prediction_frame(blk, res, bh, bw, mode);
                            float ent = estimate_residual_entropy(res, bh*bw);
                            if (ent < best_ent) {
                                best_ent = ent;
                                best_mode = mode;
                            }
                        }
                        mode_map[midx++] = best_mode;
                    }
                }
            }

            body.write_bool(true);  // has_prediction = true
            for (int idx = 0; idx < nb_pi * nb_pj; idx++)
                body.write_bits(mode_map[idx], 3);

            // Apply prediction per pred_bs block with LOCAL context
            std::memcpy(pred_buf.data(), gop_buf.data(),
                        (size_t)gop_r * nl * nc);

            for (int t = 0; t < gop_r; t++) {
                const uint8_t* src_frame = gop_buf.data() + (size_t)t * nl * nc;
                uint8_t* dst_frame = pred_buf.data() + (size_t)t * nl * nc;

                int midx = 0;
                for (int bi = 0; bi < nl; bi += pred_bs) {
                    for (int bj = 0; bj < nc; bj += pred_bs) {
                        int bh = std::min(pred_bs, nl - bi);
                        int bw = std::min(pred_bs, nc - bj);
                        int mode = mode_map[midx++];

                        uint8_t blk[64], res[64];
                        for (int i = 0; i < bh; i++)
                            for (int j = 0; j < bw; j++)
                                blk[i*bw+j] = src_frame[(bi+i)*nc + (bj+j)];

                        apply_prediction_frame(blk, res, bh, bw, mode);

                        for (int i = 0; i < bh; i++)
                            for (int j = 0; j < bw; j++)
                                dst_frame[(bi+i)*nc + (bj+j)] = res[i*bw+j];
                    }
                }
            }

            // ── Block list (16x16 fixed) ─────────────
            body.write_bool(false);  // no adaptive blocks

            struct BlockRect { int i0, i1, j0, j1; };
            std::vector<BlockRect> blocks;
            for (int bi = 0; bi < nl; bi += bs)
                for (int bj = 0; bj < nc; bj += bs)
                    blocks.push_back({bi, std::min(bi+bs, nl),
                                      bj, std::min(bj+bs, nc)});

            // ══ PHASE 1: Classify all blocks ═════════
            struct BlockInfo {
                BlockRect rect;
                PaletteInfo pal;
                int eff_bits;
                BlockClassification cls;
                uint8_t cm;
                std::vector<PixelProcess> pixels;
            };
            std::vector<BlockInfo> binfos;
            binfos.reserve(blocks.size());

            for (auto& blk : blocks) {
                BlockInfo bi;
                bi.rect = blk;
                int bh = blk.i1 - blk.i0;
                int bw = blk.j1 - blk.j0;
                int n_px = bh * bw;

                // Extract block (r frames × bh × bw)
                block_buf.resize(gop_r * bh * bw);
                for (int t = 0; t < gop_r; t++)
                    for (int i = 0; i < bh; i++)
                        for (int j = 0; j < bw; j++)
                            block_buf[t*bh*bw + i*bw + j] =
                                pred_buf[t*nl*nc + (blk.i0+i)*nc + (blk.j0+j)];

                // Palette
                bi.pal = analyze_palette(block_buf.data(), gop_r * n_px);
                bi.eff_bits = bi.pal.use_palette ? bi.pal.index_bits : color_bits;

                // Apply palette transform if useful
                std::vector<uint8_t> work(gop_r * n_px);
                if (bi.pal.use_palette) {
                    palette_transform(block_buf.data(), work.data(),
                                      gop_r * n_px, bi.pal);
                } else {
                    std::memcpy(work.data(), block_buf.data(), gop_r * n_px);
                }

                // Build pixel processes
                bi.pixels.resize(n_px);
                for (int pi = 0; pi < bh; pi++) {
                    for (int pj = 0; pj < bw; pj++) {
                        // Extract temporal sequence for this pixel
                        uint8_t seq[128];
                        for (int t = 0; t < gop_r; t++)
                            seq[t] = work[t * n_px + pi * bw + pj];
                        bi.pixels[pi*bw+pj] =
                            PixelProcess::from_sequence(seq, gop_r);
                    }
                }

                // Classify
                bi.cls = classify_block_mdl(work.data(), gop_r, bh, bw,
                                            bi.eff_bits, ct);

                // Build Code Methode
                if (bi.cls.proc_type == PROC_MONO) {
                    bi.cm = make_code_methode(PROC_MONO, REP_R1, comp_flag, col_flag);
                } else {
                    int rep_code = REP_R4;  // always R4 for now
                    bi.cm = make_code_methode(PROC_PP, rep_code, comp_flag, col_flag);
                }

                binfos.push_back(std::move(bi));
            }

            // ══ PHASE 1b: CM Huffman ═════════════════
            int cm_freq[256] = {};
            for (auto& bi : binfos) cm_freq[bi.cm]++;

            int n_distinct_cm = 0;
            for (int i = 0; i < 256; i++) if (cm_freq[i] > 0) n_distinct_cm++;

            bool use_cm_huffman = (n_distinct_cm >= 2 && binfos.size() >= 4);
            HuffmanTable cm_ht;

            if (use_cm_huffman) {
                cm_ht = HuffmanTable::from_frequencies(cm_freq, 256);
                float avg_cm = cm_ht.average_bits(cm_freq, 256);
                int overhead = cm_ht.table_overhead(7);
                int total_fixed = 7 * (int)binfos.size();
                int total_huff = overhead + (int)(avg_cm * binfos.size());
                if (total_huff >= total_fixed) use_cm_huffman = false;
            }

            body.write_bool(use_cm_huffman);
            if (use_cm_huffman) cm_ht.write_table(body, 7);

            // ══ PHASE 2: Encode all blocks ═══════════
            for (auto& bi : binfos) {
                int bh = bi.rect.i1 - bi.rect.i0;
                int bw = bi.rect.j1 - bi.rect.j0;
                int n_px = bh * bw;

                // Palette flag
                body.write_bool(bi.pal.use_palette);
                if (bi.pal.use_palette) {
                    // Write palette: m colors × color_bits
                    body.write_elias_gamma(bi.pal.m);
                    for (int i = 0; i < bi.pal.m; i++)
                        body.write_bits(bi.pal.colors[i], color_bits);
                }

                // Code Methode
                if (use_cm_huffman)
                    cm_ht.encode_symbol(body, bi.cm);
                else
                    body.write_bits(bi.cm, 7);

                if (bi.cls.proc_type == PROC_MONO) {
                    body.write_bits(bi.cls.mono_color, bi.eff_bits);
                    stats.mono_count += n_px;
                } else {
                    // Build per-block Huffman on colors
                    int color_freq[256] = {};
                    for (auto& pp : bi.pixels)
                        for (uint8_t c : pp.colors) color_freq[c]++;

                    bool has_huff = false;
                    HuffmanTable blk_ht;
                    if (use_huffman_) {
                        int n_sym = 0;
                        for (int i = 0; i < 256; i++) if (color_freq[i] > 0) n_sym++;
                        if (n_sym >= 2) {
                            blk_ht = HuffmanTable::from_frequencies(color_freq, 256);
                            float avg = blk_ht.average_bits(color_freq, 256);
                            int total_syms = 0;
                            for (auto& pp : bi.pixels) total_syms += pp.n_jumps;
                            int overhead = blk_ht.table_overhead(bi.eff_bits);
                            if (overhead + (int)(avg * total_syms) < bi.eff_bits * total_syms) {
                                has_huff = true;
                            }
                        }
                    }

                    body.write_bool(has_huff);
                    if (has_huff) blk_ht.write_table(body, bi.eff_bits);

                    // Encode each pixel as R4
                    for (auto& pp : bi.pixels) {
                        body.write_elias_gamma(pp.n_jumps);
                        int s_bits = ct.bits_for(gop_r, pp.n_jumps);
                        if (s_bits > 0)
                            body.write_bits(pp.jumps.rank(ct), s_bits);
                        for (uint8_t c : pp.colors) {
                            if (has_huff)
                                blk_ht.encode_symbol(body, c);
                            else
                                body.write_bits(c, bi.eff_bits);
                        }
                        stats.rep_counts[4]++;
                    }
                    stats.pp_count += n_px;
                }
            }
        }

        auto body_data = body.finish();

        // ── Write file ───────────────────────────────
        // Header (24 bytes, big-endian)
        uint8_t header[PPV_HEADER_SIZE];
        std::memcpy(header, PPV_MAGIC, 4);
        header[4] = PPV_VERSION;
        header[5] = 0;  // flags (grayscale)
        // Big-endian writes
        auto write_be16 = [](uint8_t* p, uint16_t v) {
            p[0] = (v >> 8) & 0xFF; p[1] = v & 0xFF;
        };
        auto write_be32 = [](uint8_t* p, uint32_t v) {
            p[0]=(v>>24)&0xFF; p[1]=(v>>16)&0xFF;
            p[2]=(v>>8)&0xFF; p[3]=v&0xFF;
        };
        write_be16(header + 6, nl);
        write_be16(header + 8, nc);
        write_be16(header + 10, r_total);
        header[12] = color_bits;
        header[13] = fps;
        write_be16(header + 14, gop_size_);
        write_be16(header + 16, nb_gops);
        write_be32(header + 18, (uint32_t)body.total_bits());
        write_be16(header + 22, 0);  // reserved

        std::ofstream out(output_path, std::ios::binary);
        out.write((const char*)header, PPV_HEADER_SIZE);
        out.write((const char*)body_data.data(), body_data.size());
        out.close();

        stats.compressed_bytes = PPV_HEADER_SIZE + body_data.size();
        stats.compression_ratio = (float)stats.raw_bytes / stats.compressed_bytes;

        return stats;
    }
};

} // namespace ppv
