// ppv_bindings.cpp — pybind11 bindings for PPV C++ core
// Exposes PPVEncoder and PPVDecoder as Python-callable objects
// with numpy array I/O for zero-copy integration.
//
// Build:
//   g++ -O3 -march=native -shared -fPIC -std=c++20 -mpopcnt -mbmi2 \
//       $(python3 -m pybind11 --includes) \
//       -I include ppv_bindings.cpp \
//       -o ppv_cpp$(python3-config --extension-suffix)

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <pybind11/stl.h>

#include "ppv_encoder.hpp"
#include "ppv_decoder.hpp"

namespace py = pybind11;
using namespace ppv;

PYBIND11_MODULE(ppv_cpp, m) {
    m.doc() = "PPV Codec C++ backend — 3000x faster than pure Python";

    // ── Encoder ───────────────────────────────────────
    py::class_<PPVEncoder>(m, "PPVEncoder")
        .def(py::init<int, int, int, bool>(),
             py::arg("gop_size") = 64,
             py::arg("block_size") = 16,
             py::arg("temporal_mode") = 2,
             py::arg("use_huffman") = true,
             "Create encoder. temporal_mode: 0=none, 1=XOR, 2=delta")

        .def("encode", [](PPVEncoder& self,
                          py::array_t<uint8_t, py::array::c_style> M,
                          const std::string& output_path,
                          int color_bits, int fps) -> py::dict {
            auto buf = M.request();

            int r, nl, nc;
            if (buf.ndim == 3) {
                r  = buf.shape[0];
                nl = buf.shape[1];
                nc = buf.shape[2];
            } else {
                throw std::runtime_error(
                    "Expected 3D array (frames, height, width), got " +
                    std::to_string(buf.ndim) + "D");
            }

            auto stats = self.encode(
                static_cast<const uint8_t*>(buf.ptr),
                nl, nc, r, output_path.c_str(), color_bits, fps
            );

            py::dict result;
            result["nl"] = stats.nl;
            result["nc"] = stats.nc;
            result["r"] = stats.r;
            result["compressed_size_bytes"] = (int)stats.compressed_bytes;
            result["compression_ratio"] = stats.compression_ratio;
            result["mono_count"] = stats.mono_count;
            result["pp_count"] = stats.pp_count;
            result["savings_percent"] =
                (1.0f - 1.0f / stats.compression_ratio) * 100;
            result["rep_counts"] = py::dict(
                py::arg("1") = stats.rep_counts[1],
                py::arg("2") = stats.rep_counts[2],
                py::arg("3") = stats.rep_counts[3],
                py::arg("4") = stats.rep_counts[4]
            );
            return result;
        },
        py::arg("M"),
        py::arg("output_path") = "output.ppv",
        py::arg("color_bits") = 8,
        py::arg("fps") = 30,
        "Encode a grayscale video (r, nl, nc) uint8 array to .ppv file");

    // ── Decoder ───────────────────────────────────────
    py::class_<PPVDecoder>(m, "PPVDecoder")
        .def(py::init<>())

        .def("decode", [](PPVDecoder& self,
                          const std::string& input_path) -> py::tuple {
            auto result = self.decode(input_path.c_str());

            // Create numpy array (r, nl, nc) with copy of decoded frames
            py::array_t<uint8_t> arr({result.r, result.nl, result.nc});
            auto buf = arr.request();
            std::memcpy(buf.ptr, result.frames.data(),
                        (size_t)result.r * result.nl * result.nc);

            py::dict meta;
            meta["nl"] = result.nl;
            meta["nc"] = result.nc;
            meta["r"] = result.r;
            meta["fps"] = result.fps;
            meta["color_bits"] = result.color_bits;
            meta["mono_count"] = result.mono_count;
            meta["pp_count"] = result.pp_count;

            return py::make_tuple(arr, meta);
        },
        py::arg("input_path"),
        "Decode a .ppv file to (numpy_array, metadata_dict)");

    // ── Utilities ─────────────────────────────────────
    m.def("version", []() { return "PPV C++ v13 — Sprint C7"; });

    m.def("benchmark_bitstream", [](int n) -> py::dict {
        auto t0 = std::chrono::high_resolution_clock::now();
        BitWriter w;
        for (int i = 0; i < n; i++) w.write_bits(i & 0xFF, 8);
        auto data = w.finish();
        auto t1 = std::chrono::high_resolution_clock::now();
        BitReader r(data);
        uint64_t sum = 0;
        for (int i = 0; i < n; i++) sum += r.read_bits(8);
        auto t2 = std::chrono::high_resolution_clock::now();

        double w_us = std::chrono::duration_cast<std::chrono::microseconds>(t1-t0).count();
        double r_us = std::chrono::duration_cast<std::chrono::microseconds>(t2-t1).count();

        py::dict result;
        result["write_mbps"] = n * 8.0 / w_us;
        result["read_mbps"] = n * 8.0 / r_us;
        result["write_us"] = w_us;
        result["read_us"] = r_us;
        result["bytes"] = (int)data.size();
        return result;
    }, py::arg("n") = 1000000, "Benchmark BitWriter/BitReader");
}
