// Minimal test: roundtrip only, no benchmark that might trigger edge cases
#include "../include/ppv_encoder.hpp"
#include "../include/ppv_decoder.hpp"
#include <iostream>
#include <cstring>
#include <random>
#include <chrono>
#include <iomanip>
using namespace ppv;
using namespace std::chrono;

void gen_static_bg(uint8_t* M, int nl, int nc, int r) {
    std::mt19937 rng(42);
    for (int i = 0; i < nl; i++)
        for (int j = 0; j < nc; j++) M[i*nc+j] = (i*7+j*13) & 0xFF;
    for (int t = 1; t < r; t++) std::memcpy(M + t*nl*nc, M, nl*nc);
    for (int t = 1; t < r; t++) {
        M[t*nl*nc + (rng()%nl)*nc + (rng()%nc)] = rng() % 256;
    }
}
void gen_gradient(uint8_t* M, int nl, int nc, int r) {
    for (int t=0;t<r;t++)for(int i=0;i<nl;i++)for(int j=0;j<nc;j++)
        M[t*nl*nc+i*nc+j]=((i+t)*255/std::max(nl-1,1))&0xFF;
}
void gen_animation(uint8_t* M, int nl, int nc, int r) {
    for (int t=0;t<r;t++) {
        uint8_t bg = (t<r/2)?0:255;
        for(int i=0;i<nl;i++)for(int j=0;j<nc;j++){
            int dx=j-nc/2,dy=i-nl/2,rad=nl/4+t%8;
            M[t*nl*nc+i*nc+j]=(dx*dx+dy*dy<rad*rad)?(200-bg):bg;
        }
    }
}
void gen_noise(uint8_t* M, int nl, int nc, int r) {
    std::mt19937 rng(123);
    for(size_t i=0;i<(size_t)r*nl*nc;i++) M[i]=rng()%256;
}

bool test_one(const char* name, int nl, int nc, int r, int temporal,
              void(*gen)(uint8_t*,int,int,int), bool use_huff=true) {
    size_t total = (size_t)r * nl * nc;
    std::vector<uint8_t> M(total);
    if (gen) gen(M.data(), nl, nc, r);
    else std::memset(M.data(), 42, total);

    int gop = std::min(r, 64);
    PPVEncoder enc(gop, 16, temporal, use_huff);
    auto stats = enc.encode(M.data(), nl, nc, r, "/tmp/rt.ppv", 8, 30);

    PPVDecoder dec;
    auto res = dec.decode("/tmp/rt.ppv");
    bool ok = res.success && res.frames.size() == total &&
              std::memcmp(res.frames.data(), M.data(), total) == 0;

    std::cout << "  " << std::left << std::setw(22) << name
              << std::right << nl << "x" << nc << "x" << r
              << "  ratio=" << std::fixed << std::setprecision(1)
              << stats.compression_ratio << "x  "
              << (ok ? "LOSSLESS" : "MISMATCH") << "\n";
    if (!ok && res.success) {
        int n=0; for(size_t i=0;i<total;i++) if(res.frames[i]!=M[i]) n++;
        std::cout << "    n_diff=" << n << "\n";
    }
    return ok;
}

int main() {
    std::cout << "╔═══════════════════════════════════════════════════╗\n";
    std::cout << "║  PPV C++ Codec — Sprint C5+C6 Full Roundtrip     ║\n";
    std::cout << "╚═══════════════════════════════════════════════════╝\n\n";
    
    bool ok = true;
    
    // Small tests
    ok &= test_one("const_16_notmp", 16,16,16, 0, nullptr);
    ok &= test_one("const_32_delta", 32,32,32, 2, nullptr);
    ok &= test_one("surv_32_notmp",  32,32,32, 0, gen_static_bg);
    ok &= test_one("surv_32_xor",    32,32,32, 1, gen_static_bg);
    ok &= test_one("surv_32_delta",  32,32,32, 2, gen_static_bg);
    ok &= test_one("grad_32_notmp",  32,32,32, 0, gen_gradient);
    ok &= test_one("grad_32_delta",  32,32,32, 2, gen_gradient);
    ok &= test_one("anim_32_notmp",  32,32,32, 0, gen_animation);
    ok &= test_one("anim_32_delta",  32,32,32, 2, gen_animation);
    ok &= test_one("noise_16_raw",   16,16,8,  0, gen_noise, false);
    ok &= test_one("noise_32_huff",  32,32,16, 0, gen_noise);
    
    // Medium
    ok &= test_one("surv_64_delta",  64,64,64, 2, gen_static_bg);
    ok &= test_one("grad_64_delta",  64,64,64, 2, gen_gradient);
    ok &= test_one("anim_64_delta",  64,64,64, 2, gen_animation);
    
    // Large
    ok &= test_one("surv_128x96",    96,128,64, 2, gen_static_bg);
    ok &= test_one("grad_128x96",    96,128,64, 2, gen_gradient);
    
    std::cout << "\n";
    
    // Benchmark on 128x96x64
    {
        int NL=96, NC=128, R=64;
        std::vector<uint8_t> M(R*NL*NC);
        gen_static_bg(M.data(), NL, NC, R);
        
        PPVEncoder enc(64, 16, 2, true);
        PPVDecoder dec;
        
        auto t0 = high_resolution_clock::now();
        enc.encode(M.data(), NL, NC, R, "/tmp/rt.ppv", 8, 30);
        auto t_enc = duration_cast<microseconds>(high_resolution_clock::now()-t0).count();
        
        auto t1 = high_resolution_clock::now();
        dec.decode("/tmp/rt.ppv");
        auto t_dec = duration_cast<microseconds>(high_resolution_clock::now()-t1).count();
        
        double mpx = (double)NL*NC*R;
        std::cout << "  BENCHMARK 128x96x64:\n";
        std::cout << "    Encode: " << t_enc/1000 << "ms  ("
                  << std::setprecision(1) << mpx/(t_enc/1e6)/1e6 << " MPx/s)\n";
        std::cout << "    Decode: " << t_dec/1000 << "ms  ("
                  << mpx/(t_dec/1e6)/1e6 << " MPx/s)\n";
        std::cout << "    Python: ~37000ms encode, ~5000ms decode\n";
        std::cout << "    Speedup: ~" << (int)(37000.0*1000/t_enc) << "x encode, ~"
                  << (int)(5000.0*1000/t_dec) << "x decode\n";
    }
    
    std::cout << "\n  " << (ok ? "✓ ALL TESTS PASS — C++ CODEC FULLY OPERATIONAL"
                                : "✗ SOME TESTS FAILED") << "\n\n";
    std::remove("/tmp/rt.ppv");
    return ok ? 0 : 1;
}
