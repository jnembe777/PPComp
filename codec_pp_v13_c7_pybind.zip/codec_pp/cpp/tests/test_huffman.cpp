// test_huffman.cpp — Tests + Benchmark for PPV Huffman
// Compile: g++ -std=c++20 -O3 -march=native -I include -o test_huff tests/test_huffman.cpp
#include "../include/ppv_core.hpp"
#include "../include/ppv_huffman.hpp"
#include <iostream>
#include <chrono>
#include <random>
#include <iomanip>
#include <cassert>
#include <map>

using namespace ppv;
using namespace std::chrono;
using clk = high_resolution_clock;

// ═══════════════════════════════════════════════════════════
//  TEST: Build + Encode/Decode roundtrip
// ═══════════════════════════════════════════════════════════

bool test_encode_decode() {
    std::cout << "  Encode/Decode roundtrip... " << std::flush;

    // Distribution: heavily skewed (like post-Paeth delta)
    int freq[256] = {};
    freq[0] = 5000;
    freq[1] = 800;
    freq[255] = 750;
    freq[2] = 300;
    freq[254] = 280;
    freq[3] = 100;
    freq[10] = 50;
    freq[128] = 20;

    auto ht = HuffmanTable::from_frequencies(freq, 256);

    // Generate test sequence matching the distribution
    std::vector<uint8_t> symbols;
    for (int s = 0; s < 256; s++) {
        for (int i = 0; i < freq[s]; i++) {
            symbols.push_back((uint8_t)s);
        }
    }
    // Shuffle
    std::mt19937 rng(42);
    std::shuffle(symbols.begin(), symbols.end(), rng);

    // Encode
    BitWriter w;
    for (uint8_t s : symbols) {
        ht.encode_symbol(w, s);
    }
    auto data = w.finish();

    // Decode
    BitReader r(data);
    bool ok = true;
    for (size_t i = 0; i < symbols.size(); i++) {
        uint8_t decoded = ht.decode_symbol(r);
        if (decoded != symbols[i]) {
            std::cerr << "FAIL at " << i << ": expected " << (int)symbols[i]
                      << " got " << (int)decoded << "\n";
            ok = false;
            break;
        }
    }

    // Check compression
    float raw_bits = symbols.size() * 8.0f;
    float huff_bits = data.size() * 8.0f;
    float ratio = raw_bits / huff_bits;

    std::cout << (ok ? "OK" : "FAIL")
              << " (n=" << symbols.size() << ", ratio=" << std::fixed
              << std::setprecision(2) << ratio << "x)\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST: Serialization roundtrip (write_table / read_table)
// ═══════════════════════════════════════════════════════════

bool test_serialization() {
    std::cout << "  Serialization roundtrip... " << std::flush;

    int freq[256] = {};
    freq[0] = 1000;
    freq[42] = 500;
    freq[100] = 200;
    freq[200] = 100;
    freq[255] = 50;

    auto ht1 = HuffmanTable::from_frequencies(freq, 256);

    // Serialize
    BitWriter w;
    ht1.write_table(w, 8);

    // Also write some encoded symbols
    std::vector<uint8_t> test_syms = {0, 42, 0, 100, 200, 0, 255, 42, 0};
    for (uint8_t s : test_syms) {
        ht1.encode_symbol(w, s);
    }
    auto data = w.finish();

    // Deserialize
    BitReader r(data);
    auto ht2 = HuffmanTable::read_table(r, 8);

    // Decode symbols using deserialized table
    bool ok = true;
    for (size_t i = 0; i < test_syms.size(); i++) {
        uint8_t decoded = ht2.decode_symbol(r);
        if (decoded != test_syms[i]) {
            std::cerr << "FAIL at " << i << ": expected " << (int)test_syms[i]
                      << " got " << (int)decoded << "\n";
            ok = false;
            break;
        }
    }

    // Verify code lengths match
    for (uint8_t s : {0, 42, 100, 200, 255}) {
        if (ht1.code_length(s) != ht2.code_length(s)) {
            std::cerr << "FAIL: length mismatch for symbol " << (int)s << "\n";
            ok = false;
        }
    }

    std::cout << (ok ? "OK" : "FAIL") << "\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST: Single symbol table
// ═══════════════════════════════════════════════════════════

bool test_single_symbol() {
    std::cout << "  Single symbol table... " << std::flush;

    int freq[256] = {};
    freq[42] = 100;

    auto ht = HuffmanTable::from_frequencies(freq, 256);

    BitWriter w;
    for (int i = 0; i < 50; i++) {
        ht.encode_symbol(w, 42);
    }
    auto data = w.finish();

    BitReader r(data);
    bool ok = true;
    for (int i = 0; i < 50; i++) {
        if (ht.decode_symbol(r) != 42) { ok = false; break; }
    }

    // Should be 50 bits (length 1 per symbol)
    std::cout << (ok ? "OK" : "FAIL")
              << " (50 symbols → " << data.size() << " bytes)\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST: Cross-validation with Python
// ═══════════════════════════════════════════════════════════

bool test_cross_validation() {
    std::cout << "  Cross-validation Python... " << std::flush;

    // Use same distribution as Python test: post-Paeth surveillance
    // Python output: symbol 0 gets shortest code, 1 and 255 get next
    int freq[256] = {};
    freq[0] = 6360;  // 63.6%
    freq[1] = 1040;  // 10.4%
    freq[255] = 960;  //  9.6%
    freq[2] = 420;   //  4.2%
    freq[254] = 370;  //  3.7%
    freq[3] = 180;
    freq[253] = 160;
    freq[4] = 80;
    freq[252] = 70;

    auto ht = HuffmanTable::from_frequencies(freq, 256);

    bool ok = true;

    // Symbol 0 should have the shortest code (most frequent)
    int len0 = ht.code_length(0);
    int len1 = ht.code_length(1);
    int len255 = ht.code_length(255);

    ok &= (len0 <= len1);
    ok &= (len0 <= len255);
    ok &= (len0 >= 1);

    // Verify average bits matches theoretical expectation
    float avg = ht.average_bits(freq, 256);
    // Should be well under 8 bits (heavy skew)
    ok &= (avg < 3.0f);
    ok &= (avg > 0.5f);

    // Full roundtrip with serialization
    BitWriter w;
    ht.write_table(w, 8);

    std::vector<uint8_t> seq;
    for (int s = 0; s < 256; s++)
        for (int i = 0; i < freq[s]; i++)
            seq.push_back((uint8_t)s);

    for (uint8_t s : seq) ht.encode_symbol(w, s);
    auto data = w.finish();

    BitReader r(data);
    auto ht2 = HuffmanTable::read_table(r, 8);
    for (size_t i = 0; i < seq.size(); i++) {
        if (ht2.decode_symbol(r) != seq[i]) { ok = false; break; }
    }

    std::cout << (ok ? "OK" : "FAIL")
              << " (avg=" << std::fixed << std::setprecision(3)
              << avg << " bps, len0=" << len0 << ")\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST: Integration with R4 pipeline
// ═══════════════════════════════════════════════════════════

bool test_r4_with_huffman() {
    std::cout << "  R4 + Huffman integration... " << std::flush;
    const auto& ct = comb_table();
    bool ok = true;

    constexpr int N = 500;
    constexpr int R = 32;
    std::mt19937 rng(123);

    // Generate sequences
    std::vector<std::vector<uint8_t>> seqs(N);
    int color_freq[256] = {};

    for (auto& s : seqs) {
        s.resize(R);
        s[0] = rng() % 4;  // only 4 colors
        for (int t = 1; t < R; t++)
            s[t] = (rng() % 10 < 2) ? (rng() % 4) : s[t-1];
        // Count color frequencies
        for (uint8_t c : s) color_freq[c]++;
    }

    // Build Huffman table
    auto ht = HuffmanTable::from_frequencies(color_freq, 256);

    // Encode: table + R4 with Huffman colors
    BitWriter w;
    ht.write_table(w, 8);

    for (auto& s : seqs) {
        auto pp = PixelProcess::from_sequence(s.data(), R);
        // Write n_jumps + S index
        w.write_elias_gamma(pp.n_jumps);
        int s_bits = ct.bits_for(R, pp.n_jumps);
        if (s_bits > 0) w.write_bits(pp.jumps.rank(ct), s_bits);
        // Write colors via Huffman
        for (uint8_t c : pp.colors) {
            ht.encode_symbol(w, c);
        }
    }
    auto data = w.finish();

    // Decode
    BitReader rd(data);
    auto ht2 = HuffmanTable::read_table(rd, 8);

    for (int i = 0; i < N; i++) {
        int n_jumps = rd.read_elias_gamma();
        int s_bits = ct.bits_for(R, n_jumps);
        uint64_t s_idx = s_bits > 0 ? rd.read_bits(s_bits) : 0;
        auto bv = BoolVec64::unrank(s_idx, R, n_jumps, ct);

        std::vector<uint8_t> colors(n_jumps);
        for (int j = 0; j < n_jumps; j++) {
            colors[j] = ht2.decode_symbol(rd);
        }

        // Reconstruct sequence
        std::vector<uint8_t> rec(R);
        int ci = 0;
        uint8_t cur = 0;
        for (int t = 0; t < R; t++) {
            if (bv.get(t)) cur = colors[ci++];
            rec[t] = cur;
        }

        if (rec != seqs[i]) {
            ok = false;
            break;
        }
    }

    float raw = N * R;
    float compressed = data.size();
    float ratio = raw / compressed;

    std::cout << (ok ? "OK" : "FAIL")
              << " (" << N << " pixels, ratio=" << std::fixed
              << std::setprecision(2) << ratio << "x)\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  BENCHMARK
// ═══════════════════════════════════════════════════════════

void benchmark() {
    std::cout << "\n  BENCHMARK Huffman C++\n";
    std::cout << "  " << std::string(60, '-') << "\n";

    // Build a realistic distribution
    int freq[256] = {};
    freq[0] = 50000;
    freq[1] = 8000;
    freq[255] = 7500;
    freq[2] = 3000;
    freq[254] = 2800;
    freq[3] = 1000;
    freq[253] = 900;
    freq[4] = 400;
    freq[128] = 200;
    freq[10] = 100;

    auto ht = HuffmanTable::from_frequencies(freq, 256);

    // Generate sequence
    constexpr int N = 1'000'000;
    std::vector<uint8_t> symbols;
    symbols.reserve(N);
    for (int s = 0; s < 256; s++)
        for (int i = 0; i < freq[s]; i++)
            symbols.push_back((uint8_t)s);
    // Pad/truncate to N
    std::mt19937 rng(42);
    std::shuffle(symbols.begin(), symbols.end(), rng);
    symbols.resize(N);

    // Benchmark encode
    auto t0 = clk::now();
    BitWriter w;
    for (uint8_t s : symbols) {
        ht.encode_symbol(w, s);
    }
    auto enc_data = w.finish();
    auto t_enc = duration_cast<microseconds>(clk::now() - t0).count();

    double enc_mps = N / (t_enc / 1e6);
    double ratio = (double)(N * 8) / (enc_data.size() * 8);

    std::cout << "  Encode       : " << std::fixed << std::setprecision(1)
              << enc_mps / 1e6 << "M sym/s  (" << t_enc << " us)\n";

    // Benchmark decode
    auto t1 = clk::now();
    BitReader r(enc_data);
    uint64_t checksum = 0;
    for (int i = 0; i < N; i++) {
        checksum += ht.decode_symbol(r);
    }
    auto t_dec = duration_cast<microseconds>(clk::now() - t1).count();

    double dec_mps = N / (t_dec / 1e6);

    std::cout << "  Decode       : " << dec_mps / 1e6
              << "M sym/s  (" << t_dec << " us)  [checksum=" << checksum << "]\n";

    // Benchmark table build
    auto t2 = clk::now();
    for (int i = 0; i < 10000; i++) {
        auto tmp = HuffmanTable::from_frequencies(freq, 256);
        (void)tmp;
    }
    auto t_build = duration_cast<microseconds>(clk::now() - t2).count();

    std::cout << "  Table build  : " << 10000.0 / (t_build / 1e6) / 1e3
              << "K tables/s  (" << t_build << " us for 10K)\n";

    std::cout << "  Ratio        : " << std::setprecision(2) << ratio
              << "x  (" << enc_data.size() / 1024 << " KB for "
              << N / 1000 << "K symbols)\n";

    std::cout << "  Avg bits     : " << std::setprecision(3)
              << ht.average_bits(freq, 256) << " bps\n";

    std::cout << "  " << std::string(60, '-') << "\n";
    std::cout << "  Python equivalents (estimated):\n";
    std::cout << "    Encode     : ~0.05M sym/s\n";
    std::cout << "    Decode     : ~0.02M sym/s\n";
    std::cout << "  → Speedup: " << (int)(enc_mps / 50000) << "x encode, "
              << (int)(dec_mps / 20000) << "x decode\n";
}


// ═══════════════════════════════════════════════════════════
//  MAIN
// ═══════════════════════════════════════════════════════════

int main() {
    std::cout << "╔══════════════════════════════════════════════╗\n";
    std::cout << "║  PPV C++ Huffman — Sprint C4                 ║\n";
    std::cout << "║  Canonical Huffman + fast decode              ║\n";
    std::cout << "╚══════════════════════════════════════════════╝\n\n";

    bool all_ok = true;

    std::cout << "  TESTS:\n";
    all_ok &= test_encode_decode();
    all_ok &= test_serialization();
    all_ok &= test_single_symbol();
    all_ok &= test_cross_validation();
    all_ok &= test_r4_with_huffman();

    benchmark();

    std::cout << "\n  " << (all_ok ? "✓ ALL TESTS PASS" : "✗ SOME TESTS FAILED")
              << "\n\n";

    return all_ok ? 0 : 1;
}
