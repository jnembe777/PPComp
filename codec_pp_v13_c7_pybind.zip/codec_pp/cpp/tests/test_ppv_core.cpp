// test_ppv_core.cpp — Tests + Benchmark for PPV C++ Core
// Compile: g++ -std=c++20 -O3 -march=native -mbmi2 -mpopcnt -o test_ppv test_ppv_core.cpp

#include "../include/ppv_core.hpp"
#include <iostream>
#include <chrono>
#include <cassert>
#include <random>
#include <iomanip>

using namespace ppv;
using namespace std::chrono;
using clk = high_resolution_clock;

// ═══════════════════════════════════════════════════════════
//  TEST BITSTREAM
// ═══════════════════════════════════════════════════════════

bool test_bitstream() {
    std::cout << "  BitStream... " << std::flush;

    // Write various bit widths
    BitWriter w;
    w.write_bits(0b10110, 5);
    w.write_bits(0xFF, 8);
    w.write_bool(true);
    w.write_bool(false);
    w.write_bits(0xABCD, 16);
    w.write_uint16(12345);
    w.write_elias_gamma(1);
    w.write_elias_gamma(7);
    w.write_elias_gamma(42);
    w.write_elias_gamma(1000);

    auto data = w.finish();
    BitReader r(data);

    bool ok = true;
    ok &= (r.read_bits(5) == 0b10110);
    ok &= (r.read_bits(8) == 0xFF);
    ok &= (r.read_bool() == true);
    ok &= (r.read_bool() == false);
    ok &= (r.read_bits(16) == 0xABCD);
    ok &= (r.read_uint16() == 12345);
    ok &= (r.read_elias_gamma() == 1);
    ok &= (r.read_elias_gamma() == 7);
    ok &= (r.read_elias_gamma() == 42);
    ok &= (r.read_elias_gamma() == 1000);

    std::cout << (ok ? "OK" : "FAIL") << "\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST COMBINATORICS
// ═══════════════════════════════════════════════════════════

bool test_combinatorics() {
    std::cout << "  Combinatorics... " << std::flush;
    const auto& ct = comb_table();

    bool ok = true;

    // Basic C(n,k)
    ok &= (ct.C(10, 3) == 120);
    ok &= (ct.C(64, 32) == 1832624140942590534ULL);
    ok &= (ct.C(20, 0) == 1);
    ok &= (ct.C(20, 20) == 1);
    ok &= (ct.C(0, 0) == 1);

    // bits_for
    ok &= (ct.bits_for(10, 3) == 7);  // ceil(log2(120)) = 7

    // Ranking/unranking roundtrip
    for (int r = 4; r <= 64; r *= 2) {
        for (int n = 1; n <= std::min(r, 10); n++) {
            uint64_t max_idx = ct.C(r, n);
            // Test a few indices
            for (uint64_t idx = 0; idx < std::min(max_idx, (uint64_t)100); idx++) {
                auto bv = BoolVec64::unrank(idx, r, n, ct);
                ok &= (bv.popcount() == n);
                uint64_t re_idx = bv.rank(ct);
                if (re_idx != idx) {
                    std::cerr << "  FAIL rank/unrank: r=" << r
                              << " n=" << n << " idx=" << idx
                              << " got=" << re_idx << "\n";
                    ok = false;
                }
            }
        }
    }

    std::cout << (ok ? "OK" : "FAIL") << "\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST BOOLVEC64
// ═══════════════════════════════════════════════════════════

bool test_boolvec() {
    std::cout << "  BoolVec64... " << std::flush;
    bool ok = true;

    BoolVec64 bv{0, 32};
    bv.set(0);
    bv.set(5);
    bv.set(10);
    bv.set(31);

    ok &= (bv.popcount() == 4);
    ok &= (bv.get(0) == true);
    ok &= (bv.get(1) == false);
    ok &= (bv.get(5) == true);
    ok &= (bv.get(31) == true);
    ok &= (bv.first_set() == 0);

    // for_each_set
    std::vector<int> positions;
    bv.for_each_set([&](int t) { positions.push_back(t); });
    ok &= (positions == std::vector<int>{0, 5, 10, 31});

    std::cout << (ok ? "OK" : "FAIL") << "\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST PIXEL PROCESS R4
// ═══════════════════════════════════════════════════════════

bool test_pixel_r4() {
    std::cout << "  PixelProcess R4... " << std::flush;
    bool ok = true;
    const auto& ct = comb_table();

    // Generate test sequences
    std::mt19937 rng(42);

    for (int trial = 0; trial < 1000; trial++) {
        int r = 16 + (rng() % 48);  // r in [16, 63]
        int n_colors = 2 + (rng() % 6);
        float change_prob = 0.05f + (rng() % 30) / 100.0f;

        std::vector<uint8_t> seq(r);
        seq[0] = rng() % n_colors;
        for (int t = 1; t < r; t++) {
            if ((rng() % 100) < (int)(change_prob * 100))
                seq[t] = rng() % n_colors;
            else
                seq[t] = seq[t-1];
        }

        // Build process
        auto pp = PixelProcess::from_sequence(seq.data(), r);

        // Encode
        BitWriter w;
        pp.encode_R4(w, r, 8, ct);
        auto data = w.finish();

        // Decode
        BitReader rd(data);
        auto pp2 = PixelProcess::decode_R4(rd, r, 8, ct);

        // Reconstruct
        std::vector<uint8_t> rec(r);
        pp2.to_sequence(rec.data(), r);

        if (rec != seq) {
            std::cerr << "  FAIL R4 roundtrip trial " << trial
                      << " r=" << r << " n_jumps=" << pp.n_jumps << "\n";
            ok = false;
            break;
        }
    }

    std::cout << (ok ? "OK (1000 trials)" : "FAIL") << "\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  TEST NCD (distinct colors via bitmap)
// ═══════════════════════════════════════════════════════════

bool test_ncd() {
    std::cout << "  NCD bitmap... " << std::flush;
    bool ok = true;

    uint8_t data1[] = {42, 42, 42, 42};
    ok &= (BlockMetrics::count_distinct_colors(data1, 4) == 1);

    uint8_t data2[] = {0, 1, 2, 3, 255, 128, 64, 32};
    ok &= (BlockMetrics::count_distinct_colors(data2, 8) == 8);

    // All 256 values
    uint8_t data3[256];
    for (int i = 0; i < 256; i++) data3[i] = i;
    ok &= (BlockMetrics::count_distinct_colors(data3, 256) == 256);

    std::cout << (ok ? "OK" : "FAIL") << "\n";
    return ok;
}


// ═══════════════════════════════════════════════════════════
//  BENCHMARK vs Python
// ═══════════════════════════════════════════════════════════

void benchmark() {
    std::cout << "\n  BENCHMARK C++ vs Python (estimé)\n";
    std::cout << "  " << std::string(60, '-') << "\n";
    const auto& ct = comb_table();

    // 1. Ranking/unranking speed
    {
        constexpr int N = 1'000'000;
        auto t0 = clk::now();
        uint64_t checksum = 0;
        for (int i = 0; i < N; i++) {
            auto bv = BoolVec64::unrank(i % 120, 10, 3, ct);
            checksum += bv.rank(ct);
        }
        auto dt = duration_cast<microseconds>(clk::now() - t0).count();
        double ops = N / (dt / 1e6);
        std::cout << "  Rank/unrank  : " << std::fixed << std::setprecision(1)
                  << ops / 1e6 << "M ops/s  (" << dt << " us for "
                  << N/1000 << "K)  [checksum=" << checksum << "]\n";
    }

    // 2. BitWriter speed
    {
        constexpr int N = 10'000'000;
        BitWriter w;
        auto t0 = clk::now();
        for (int i = 0; i < N; i++) {
            w.write_bits(i & 0xFF, 8);
        }
        auto data = w.finish();
        auto dt = duration_cast<microseconds>(clk::now() - t0).count();
        double mbps = (N * 8.0) / dt;  // megabits per second
        std::cout << "  BitWriter    : " << std::fixed << std::setprecision(0)
                  << mbps << " Mbps  (" << data.size() / 1024
                  << " KB output, " << dt << " us)\n";
    }

    // 3. BitReader speed
    {
        // Prepare data
        BitWriter w;
        constexpr int N = 10'000'000;
        for (int i = 0; i < N; i++) w.write_bits(i & 0xFF, 8);
        auto data = w.finish();

        auto t0 = clk::now();
        BitReader r(data);
        uint64_t sum = 0;
        for (int i = 0; i < N; i++) {
            sum += r.read_bits(8);
        }
        auto dt = duration_cast<microseconds>(clk::now() - t0).count();
        double mbps = (N * 8.0) / dt;
        std::cout << "  BitReader    : " << std::fixed << std::setprecision(0)
                  << mbps << " Mbps  (" << dt << " us)  [sum="
                  << sum << "]\n";
    }

    // 4. Encode/decode R4 pipeline
    {
        constexpr int N_PIXELS = 100'000;
        constexpr int R = 32;
        std::mt19937 rng(42);

        // Generate sequences
        std::vector<std::vector<uint8_t>> seqs(N_PIXELS);
        for (auto& s : seqs) {
            s.resize(R);
            s[0] = rng() % 8;
            for (int t = 1; t < R; t++)
                s[t] = (rng() % 10 < 2) ? (rng() % 8) : s[t-1];
        }

        // Encode all
        auto t0 = clk::now();
        BitWriter w;
        for (auto& s : seqs) {
            auto pp = PixelProcess::from_sequence(s.data(), R);
            pp.encode_R4(w, R, 8, ct);
        }
        auto enc_data = w.finish();
        auto t_enc = duration_cast<microseconds>(clk::now() - t0).count();

        // Decode all
        auto t1 = clk::now();
        BitReader rd(enc_data);
        size_t errors = 0;
        for (int i = 0; i < N_PIXELS; i++) {
            auto pp = PixelProcess::decode_R4(rd, R, 8, ct);
            std::vector<uint8_t> rec(R);
            pp.to_sequence(rec.data(), R);
            if (rec != seqs[i]) errors++;
        }
        auto t_dec = duration_cast<microseconds>(clk::now() - t1).count();

        double enc_pps = N_PIXELS / (t_enc / 1e6);
        double dec_pps = N_PIXELS / (t_dec / 1e6);
        double ratio = (double)(N_PIXELS * R) / enc_data.size();

        std::cout << "  R4 encode    : " << std::fixed << std::setprecision(1)
                  << enc_pps / 1e6 << "M px/s  (" << t_enc << " us, "
                  << N_PIXELS/1000 << "K pixels)\n";
        std::cout << "  R4 decode    : " << dec_pps / 1e6
                  << "M px/s  (" << t_dec << " us, errors=" << errors << ")\n";
        std::cout << "  R4 ratio     : " << std::setprecision(2)
                  << ratio << "x  (" << enc_data.size() / 1024
                  << " KB for " << N_PIXELS/1000 << "K pixels x "
                  << R << " frames)\n";
    }

    // 5. NCD speed (count distinct colors)
    {
        constexpr int N = 1'000'000;
        uint8_t block[64 * 32];  // 16x16 block, 32 frames equivalent
        std::mt19937 rng(42);
        for (auto& b : block) b = rng() % 256;

        auto t0 = clk::now();
        int total_m = 0;
        for (int i = 0; i < N; i++) {
            total_m += BlockMetrics::count_distinct_colors(block, sizeof(block));
        }
        auto dt = duration_cast<microseconds>(clk::now() - t0).count();
        double ops = N / (dt / 1e6);
        std::cout << "  NCD (m)      : " << std::fixed << std::setprecision(1)
                  << ops / 1e6 << "M blocs/s  (" << dt << " us)  "
                  << "[m=" << total_m / N << "]\n";
    }

    // Summary
    std::cout << "  " << std::string(60, '-') << "\n";
    std::cout << "  Python equivalents (measured):\n";
    std::cout << "    BitWriter  : ~5 Mbps\n";
    std::cout << "    R4 encode  : ~0.001M px/s\n";
    std::cout << "    NCD        : ~0.01M blocs/s\n";
    std::cout << "  → Speedup attendu: 50-500x\n";
}


// ═══════════════════════════════════════════════════════════
//  MAIN
// ═══════════════════════════════════════════════════════════

int main() {
    std::cout << "╔══════════════════════════════════════════════╗\n";
    std::cout << "║  PPV C++ Core — Tests + Benchmark            ║\n";
    std::cout << "║  Sprint C1 (BitStream) + C2 (Combinatorics)  ║\n";
    std::cout << "║  Sprint C3 (R4 encode/decode)                ║\n";
    std::cout << "╚══════════════════════════════════════════════╝\n\n";

    bool all_ok = true;

    std::cout << "  TESTS:\n";
    all_ok &= test_bitstream();
    all_ok &= test_combinatorics();
    all_ok &= test_boolvec();
    all_ok &= test_pixel_r4();
    all_ok &= test_ncd();

    benchmark();

    std::cout << "\n  " << (all_ok ? "✓ ALL TESTS PASS" : "✗ SOME TESTS FAILED")
              << "\n\n";

    return all_ok ? 0 : 1;
}
