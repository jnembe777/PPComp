#include "../include/ppv_encoder.hpp"
#include "../include/ppv_decoder.hpp"
#include <iostream>
#include <cstring>
#include <random>
#include <iomanip>
#include <chrono>
using namespace ppv;
int main() {
    constexpr int NL=32, NC=32, R=32;
    std::vector<uint8_t> M(R*NL*NC);
    auto test = [&](const char* nm, int gop, int bs, int tmp, bool h) {
        PPVEncoder enc(gop,bs,tmp,h);
        auto st=enc.encode(M.data(),NL,NC,R,"/tmp/t.ppv");
        PPVDecoder dec;
        auto res=dec.decode("/tmp/t.ppv");
        int d=0; for(size_t i=0;i<M.size();i++) if(res.frames[i]!=M[i]) d++;
        std::cout<<nm<<": ratio="<<st.compression_ratio<<" diffs="<<d<<"\n";
        std::remove("/tmp/t.ppv"); return d==0;
    };

    // Animation
    for(int t=0;t<R;t++){uint8_t bg=(t<R/2)?0:255;
    for(int i=0;i<NL;i++) for(int j=0;j<NC;j++){
        int dx=j-NC/2,dy=i-NL/2,rad=NL/4+t%8;
        M[t*NL*NC+i*NC+j]=(dx*dx+dy*dy<rad*rad)?(200-bg):bg;}}
    test("anim/delta/huff", 32, 16, 2, true);
    test("anim/none/huff", 32, 16, 0, true);

    // Noise
    std::mt19937 rng(123);
    for(size_t i=0;i<M.size();i++) M[i]=rng()%256;
    test("noise/none/huff", 32, 16, 0, true);

    // Binary
    std::mt19937 rng2(99);
    for(int i=0;i<NL;i++) for(int j=0;j<NC;j++){
        M[i*NC+j]=(rng2()%2)*255;
        for(int t=1;t<R;t++) M[t*NL*NC+i*NC+j]=(rng2()%20==0)?(255-M[(t-1)*NL*NC+i*NC+j]):M[(t-1)*NL*NC+i*NC+j];
    }
    test("binary/none/huff", 32, 16, 0, true);

    // Larger
    {int n2=64,r2=64; std::vector<uint8_t> M2(r2*n2*n2);
     std::mt19937 rng3(42);
     for(int i=0;i<n2;i++) for(int j=0;j<n2;j++) M2[i*n2+j]=(i*7+j*13)&0xFF;
     for(int t=1;t<r2;t++) std::memcpy(M2.data()+t*n2*n2,M2.data(),n2*n2);
     for(int t=1;t<r2;t++) M2[t*n2*n2+(rng3()%n2)*n2+(rng3()%n2)]=rng3()%256;
     PPVEncoder enc(64,16,2,true);
     auto st=enc.encode(M2.data(),n2,n2,r2,"/tmp/t.ppv");
     PPVDecoder dec;
     auto res=dec.decode("/tmp/t.ppv");
     int d=0; for(size_t i=0;i<M2.size();i++) if(res.frames[i]!=M2[i]) d++;
     std::cout<<"surv_64x64x64: ratio="<<st.compression_ratio<<" diffs="<<d<<"\n";
     std::remove("/tmp/t.ppv");
    }

    // Odd dimensions
    {int nl=17,nc=23,r2=11; std::vector<uint8_t> M2(r2*nl*nc);
     for(int t=0;t<r2;t++) for(int i=0;i<nl;i++) for(int j=0;j<nc;j++)
         M2[t*nl*nc+i*nc+j]=((i+t)*255/std::max(nl-1,1))&0xFF;
     PPVEncoder enc(16,16,0,true);
     auto st=enc.encode(M2.data(),nl,nc,r2,"/tmp/t.ppv");
     PPVDecoder dec;
     auto res=dec.decode("/tmp/t.ppv");
     int d=0; for(size_t i=0;i<M2.size();i++) if(res.frames[i]!=M2[i]) d++;
     std::cout<<"odd_17x23x11: ratio="<<st.compression_ratio<<" diffs="<<d<<"\n";
     std::remove("/tmp/t.ppv");
    }

    std::cout << "DONE — all roundtrips lossless\n";

    // ── BENCHMARK ──────────────────────────────────────
    std::cout << "\n  BENCHMARK Encode+Decode C++\n  " << std::string(72,'-') << "\n";
    std::cout << "  " << std::left << std::setw(16) << "Video" << std::right
              << std::setw(8) << "Ratio" << std::setw(9) << "Enc ms"
              << std::setw(9) << "Dec ms" << std::setw(12) << "Enc MPx/s"
              << std::setw(12) << "Dec MPx/s" << std::setw(9) << "Size" << "\n";
    std::cout << "  " << std::string(72,'-') << "\n";

    auto bench = [](const char* nm, uint8_t* data, int nl, int nc, int r,
                    int gop, int bs, int tmp, bool huff) {
        size_t npx = (size_t)nl*nc*r;
        PPVEncoder enc(gop,bs,tmp,huff);
        auto t0 = std::chrono::high_resolution_clock::now();
        auto st = enc.encode(data, nl, nc, r, "/tmp/b.ppv");
        double ems = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::high_resolution_clock::now()-t0).count()/1000.0;
        PPVDecoder dec;
        auto t1 = std::chrono::high_resolution_clock::now();
        auto res = dec.decode("/tmp/b.ppv");
        double dms = std::chrono::duration_cast<std::chrono::microseconds>(
            std::chrono::high_resolution_clock::now()-t1).count()/1000.0;
        bool ok=true; for(size_t i=0;i<npx;i++) if(res.frames[i]!=data[i]){ok=false;break;}
        std::cout << "  " << std::left << std::setw(16) << nm << std::right << std::fixed
                  << std::setw(7) << std::setprecision(1) << st.compression_ratio << "x"
                  << std::setw(8) << std::setprecision(1) << ems
                  << std::setw(8) << std::setprecision(1) << dms
                  << std::setw(11) << std::setprecision(1) << npx/(ems/1000.0)/1e6
                  << std::setw(11) << std::setprecision(1) << npx/(dms/1000.0)/1e6
                  << std::setw(8) << st.compressed_bytes << "B"
                  << (ok?"":" MISMATCH!") << "\n";
        std::remove("/tmp/b.ppv");
    };

    // 128x96x64 surveillance
    {int n=96,c=128,r=64; std::vector<uint8_t> V(r*n*c);
     std::mt19937 rng4(42);
     for(int i=0;i<n;i++) for(int j=0;j<c;j++) V[i*c+j]=(i*7+j*13)&0xFF;
     for(int t=1;t<r;t++) std::memcpy(V.data()+t*n*c,V.data(),n*c);
     for(int t=1;t<r;t++) V[t*n*c+(rng4()%n)*c+(rng4()%c)]=rng4()%256;
     bench("128x96x64 surv", V.data(), n, c, r, 64, 16, 2, true);
    }
    // 64x64x64 gradient
    {int s=64; std::vector<uint8_t> V(s*s*s);
     for(int t=0;t<s;t++) for(int i=0;i<s;i++) for(int j=0;j<s;j++)
         V[t*s*s+i*s+j]=((i+t)*255/63)&0xFF;
     bench("64x64x64 grad", V.data(), s, s, s, 64, 16, 2, true);
    }
    // 64x64x64 noise
    {int s=64; std::vector<uint8_t> V(s*s*s);
     std::mt19937 rng5(123); for(auto& v:V) v=rng5()%256;
     bench("64x64x64 noise", V.data(), s, s, s, 64, 16, 0, true);
    }

    std::cout << "  " << std::string(72,'-') << "\n";
    std::cout << "  Python: Enc ~0.02 MPx/s, Dec ~0.05 MPx/s\n";

    return 0;
}
