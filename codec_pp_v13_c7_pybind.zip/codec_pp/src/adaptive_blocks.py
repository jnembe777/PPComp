"""
Adaptive Blocks — Taille de bloc variable selon le contenu.

Principe : pour chaque region du plan, choisir entre 8x8 et 16x16
selon les metriques locales :
  - Si H_spatial faible et m petit → 16x16 (moins d'overhead)
  - Si H_spatial eleve ou m grand  → 8x8  (meilleure granularite)

Le plan est d'abord decoupage en super-blocs 16x16.
Pour chaque super-bloc, on calcule le score et on decide :
  - Si score < seuil → encoder comme un seul bloc 16x16
  - Sinon → decouper en 4 sous-blocs 8x8

Le bitstream encode 1 bit par super-bloc (0 = 16x16, 1 = split 4x8x8).
"""

import numpy as np
from math import ceil, log2
from typing import Tuple
from collections import Counter


def compute_block_complexity(block: np.ndarray) -> float:
    """
    Score de complexite d'un bloc spatio-temporel.
    Score eleve = contenu complexe = preferer petits blocs.
    Score faible = contenu simple = preferer gros blocs.

    Features utilisees :
      - m : nombre de couleurs distinctes (normalise par taille)
      - sigma : ecart-type spatial moyen
      - tau : taux de changement temporel
    """
    r, bh, bw = block.shape
    n_pixels = bh * bw

    # m normalise
    m = len(np.unique(block))
    m_norm = m / (n_pixels * r)  # 0 = mono, 1 = toutes differentes

    # Ecart-type spatial moyen (sur les frames)
    sigma = np.mean([np.std(block[t].astype(float)) for t in range(r)])
    sigma_norm = sigma / 128.0  # normalise sur [0, ~1]

    # Taux de changement temporel
    if r > 1:
        changes = np.sum(block[1:] != block[:-1])
        tau = changes / (n_pixels * (r - 1))
    else:
        tau = 0.0

    # Score combine (pondere empiriquement)
    score = 0.4 * m_norm + 0.3 * sigma_norm + 0.3 * tau

    return float(score)


def compute_split_map(
    plane: np.ndarray,
    threshold: float = 0.15,
) -> np.ndarray:
    """
    Pour chaque super-bloc 16x16, decide s'il faut splitter en 4x8x8.

    Args:
        plane: shape (r, nl, nc)
        threshold: seuil de complexite (au-dessus → split)

    Returns:
        split_map: shape (nb_super_i, nb_super_j), dtype bool
                   True = split en 4x8x8, False = garder 16x16
    """
    r, nl, nc = plane.shape
    nb_si = ceil(nl / 16)
    nb_sj = ceil(nc / 16)

    split_map = np.zeros((nb_si, nb_sj), dtype=bool)

    for si in range(nb_si):
        for sj in range(nb_sj):
            i0 = si * 16
            i1 = min(i0 + 16, nl)
            j0 = sj * 16
            j1 = min(j0 + 16, nc)

            super_block = plane[:, i0:i1, j0:j1]
            score = compute_block_complexity(super_block)

            split_map[si, sj] = (score > threshold)

    return split_map


def get_adaptive_block_list(
    nl: int, nc: int, split_map: np.ndarray
) -> list:
    """
    Genere la liste des blocs (i0, i1, j0, j1) selon la split_map.

    Returns:
        Liste de tuples (i0, i1, j0, j1)
    """
    nb_si, nb_sj = split_map.shape
    blocks = []

    for si in range(nb_si):
        for sj in range(nb_sj):
            i0 = si * 16
            i1 = min(i0 + 16, nl)
            j0 = sj * 16
            j1 = min(j0 + 16, nc)

            if split_map[si, sj]:
                # Split en 4 sous-blocs 8x8
                mid_i = i0 + min(8, i1 - i0)
                mid_j = j0 + min(8, j1 - j0)
                for bi0, bi1 in [(i0, mid_i), (mid_i, i1)]:
                    for bj0, bj1 in [(j0, mid_j), (mid_j, j1)]:
                        if bi1 > bi0 and bj1 > bj0:
                            blocks.append((bi0, bi1, bj0, bj1))
            else:
                # Un seul bloc 16x16
                blocks.append((i0, i1, j0, j1))

    return blocks
