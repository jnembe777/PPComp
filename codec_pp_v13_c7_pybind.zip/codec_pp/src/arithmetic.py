"""
Arithmetic Coding — Codeur/décodeur arithmétique adaptatif.

Atteint l'entropie théorique là où Huffman arrondit au bit supérieur.
Modèle adaptatif : les fréquences sont mises à jour après chaque symbole.
"""

from typing import List
from math import log2
from collections import Counter

PRECISION = 24
TOP = 1 << PRECISION
HALF = TOP >> 1
QUARTER = TOP >> 2
MAX_FREQ = (1 << 14) - 1


class AdaptiveModel:
    def __init__(self, n_symbols: int):
        self.n = n_symbols
        self.freq = [1] * n_symbols
        self.total = n_symbols

    def get_prob(self, symbol: int):
        cum = sum(self.freq[:symbol])
        return cum, cum + self.freq[symbol], self.total

    def update(self, symbol: int):
        self.freq[symbol] += 1
        self.total += 1
        if self.total > MAX_FREQ:
            self.freq = [max(1, f >> 1) for f in self.freq]
            self.total = sum(self.freq)

    def get_symbol(self, cum_value: int):
        cum = 0
        for i in range(self.n):
            cum += self.freq[i]
            if cum > cum_value:
                return i, cum - self.freq[i], cum
        return self.n - 1, self.total - self.freq[-1], self.total


class ArithmeticEncoder:
    def __init__(self):
        self.low = 0
        self.high = TOP - 1
        self.pending = 0
        self.output = []

    def _output_bit(self, bit):
        self.output.append(bit)
        while self.pending > 0:
            self.output.append(1 - bit)
            self.pending -= 1

    def encode_symbol(self, model, symbol):
        cum_low, cum_high, total = model.get_prob(symbol)
        rng = self.high - self.low + 1
        self.high = self.low + (rng * cum_high) // total - 1
        self.low = self.low + (rng * cum_low) // total
        while True:
            if self.high < HALF:
                self._output_bit(0)
            elif self.low >= HALF:
                self._output_bit(1)
                self.low -= HALF
                self.high -= HALF
            elif self.low >= QUARTER and self.high < 3 * QUARTER:
                self.pending += 1
                self.low -= QUARTER
                self.high -= QUARTER
            else:
                break
            self.low <<= 1
            self.high = (self.high << 1) | 1
        model.update(symbol)

    def finish(self):
        self.pending += 1
        if self.low < QUARTER:
            self._output_bit(0)
        else:
            self._output_bit(1)
        n_bits = len(self.output)
        result = bytearray()
        val = 0
        cnt = 0
        for b in self.output:
            val = (val << 1) | b
            cnt += 1
            if cnt == 8:
                result.append(val)
                val = 0
                cnt = 0
        if cnt > 0:
            result.append(val << (8 - cnt))
        return bytes(result), n_bits


class ArithmeticDecoder:
    def __init__(self, data, n_bits):
        self.bits = []
        for byte in data:
            for i in range(7, -1, -1):
                self.bits.append((byte >> i) & 1)
        self.pos = 0
        self.low = 0
        self.high = TOP - 1
        self.value = 0
        for _ in range(PRECISION):
            self.value = (self.value << 1) | self._read_bit()

    def _read_bit(self):
        if self.pos < len(self.bits):
            b = self.bits[self.pos]
            self.pos += 1
            return b
        return 0

    def decode_symbol(self, model):
        rng = self.high - self.low + 1
        cum = ((self.value - self.low + 1) * model.total - 1) // rng
        symbol, cum_low, cum_high = model.get_symbol(cum)
        self.high = self.low + (rng * cum_high) // model.total - 1
        self.low = self.low + (rng * cum_low) // model.total
        while True:
            if self.high < HALF:
                pass
            elif self.low >= HALF:
                self.low -= HALF
                self.high -= HALF
                self.value -= HALF
            elif self.low >= QUARTER and self.high < 3 * QUARTER:
                self.low -= QUARTER
                self.high -= QUARTER
                self.value -= QUARTER
            else:
                break
            self.low <<= 1
            self.high = (self.high << 1) | 1
            self.value = (self.value << 1) | self._read_bit()
        model.update(symbol)
        return symbol


def arithmetic_encode(symbols, n_symbols=256):
    model = AdaptiveModel(n_symbols)
    enc = ArithmeticEncoder()
    for s in symbols:
        enc.encode_symbol(model, s)
    data, n_bits = enc.finish()
    return data, n_bits, len(symbols)


def arithmetic_decode(data, n_bits, n_to_decode, n_symbols=256):
    model = AdaptiveModel(n_symbols)
    dec = ArithmeticDecoder(data, n_bits)
    return [dec.decode_symbol(model) for _ in range(n_to_decode)]


def estimate_arithmetic_bits(freq):
    total = sum(freq.values())
    if total == 0:
        return 0
    entropy = sum(-c/total * log2(c/total) for c in freq.values() if c > 0)
    return entropy * total
