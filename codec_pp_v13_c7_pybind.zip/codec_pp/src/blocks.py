"""
Blocks v3 — Macroblocs avec prédiction intra-bloc + classification MDL.

Pipeline encodage par plan :
  1. Choix du mode de prédiction par bloc (4 modes, 2 bits/bloc)
  2. Application de la prédiction → résidus (distribution concentrée)
  3. Construction des matrices sur les résidus
  4. Classification MDL par bloc (Mono/PP/Spatial/Markov)
  5. Encodage des résidus avec la rep optimale + Huffman

Pipeline décodage par plan :
  1. Lecture des modes de prédiction
  2. Décodage des résidus (pipeline standard)
  3. Inversion de la prédiction → valeurs originales
"""

import numpy as np
from typing import List, Dict, Optional
from math import ceil, log2
from collections import Counter

from .bitstream import BitWriter, BitReader
from .matrices import build_all_matrices, compute_representation_lengths
from .representations import (
    encode_R1, encode_R2, encode_R3, encode_R4,
    decode_R1, decode_R2, decode_R3, decode_R4,
)
from .huffman import HuffmanTable
from .format import (
    make_code_methode, parse_code_methode,
    PROC_MONO, PROC_PP, PROC_SPATIAL, PROC_MARKOV,
    REP_R1, REP_R2, REP_R3, REP_R4,
    COMP_NONE, COMP_HUFFMAN,
)
from .combinatorics import bits_for_binomial, index_to_bool_vector
from .process_types import (
    _analyze_block_pixels, classify_block,
    encode_spatial, decode_spatial,
    encode_markov_v2, decode_markov,
)
from .prediction import (
    choose_best_mode_plane,
    apply_prediction_by_blocks,
    invert_prediction_by_blocks,
    PRED_BYPASS, NUM_PRED_MODES, PRED_NAMES,
)


def _build_block_entropy(pixels, color_bits, use_huffman):
    """
    Choisit le meilleur codage entropique pour un bloc.

    Returns:
        (htable_or_None, mode)
        mode: 0 = raw (fixe), 1 = Huffman, 2 = arithmétique estimé
              (pour l'instant on utilise Huffman avec le gain arith comme proxy)
    """
    if not use_huffman:
        return None, 0

    color_freq = Counter()
    for px in pixels:
        for c in px['colors']:
            color_freq[c] += 1

    if len(color_freq) < 2:
        return None, 0

    total_syms = sum(color_freq.values())

    # Estimer coût Huffman
    candidate = HuffmanTable.from_frequencies(dict(color_freq))
    avg_huff = candidate.average_bits(dict(color_freq))
    n_sym = len(color_freq)
    overhead_huff = n_sym * (color_bits + 5) + max(2 * n_sym.bit_length() - 1, 1)
    cost_huff = overhead_huff + int(avg_huff * total_syms)

    # Coût fixe
    cost_raw = color_bits * total_syms

    if cost_huff < cost_raw:
        return candidate, 1
    return None, 0


def _build_block_huffman(pixels, color_bits, use_huffman):
    """Wrapper de compatibilité."""
    htable, mode = _build_block_entropy(pixels, color_bits, use_huffman)
    return htable, (mode == 1)


# ═══════════════════════════════════════════════════════════════
#  ENCODAGE
# ═══════════════════════════════════════════════════════════════

def encode_plane_blocks(
    writer: BitWriter,
    plane: np.ndarray,
    pnl: int, pnc: int, gop_r: int,
    color_bits: int, col_flag: int,
    block_size: int,
    use_huffman: bool,
    stats: dict,
    plane_name: str,
    use_prediction: bool = True,
    heuristic=None,
    use_adaptive_blocks: bool = False,
) -> None:
    gop_duration_bits = max(1, ceil(log2(max(gop_r, 2))))
    comp_flag = COMP_HUFFMAN if use_huffman else COMP_NONE
    nb_bi = ceil(pnl / block_size)
    nb_bj = ceil(pnc / block_size)

    # ── 1. Prédiction (toujours sur grille 8×8) ──────────────────
    pred_bs = 8  # prediction toujours sur 8x8
    nb_pred_i = ceil(pnl / pred_bs)
    nb_pred_j = ceil(pnc / pred_bs)
    if use_prediction:
        if heuristic is not None:
            from .heuristic import extract_block_features
            mode_map = np.zeros((nb_pred_i, nb_pred_j), dtype=np.int32)
            for bi in range(nb_pred_i):
                for bj in range(nb_pred_j):
                    i0 = bi * pred_bs
                    i1 = min(i0 + pred_bs, pnl)
                    j0 = bj * pred_bs
                    j1 = min(j0 + pred_bs, pnc)
                    feats = extract_block_features(
                        plane, i0, i1, j0, j1, gop_r
                    )
                    _, pred_mode = heuristic.predict_method(feats)
                    mode_map[bi, bj] = pred_mode
        else:
            mode_map = choose_best_mode_plane(plane, pred_bs)
        residuals = apply_prediction_by_blocks(plane, mode_map, pred_bs)
    else:
        mode_map = np.zeros((nb_pred_i, nb_pred_j), dtype=np.int32)
        residuals = plane

    # Écrire le flag prédiction (1 bit) + modes (2 bits par bloc 8x8)
    writer.write_bool(use_prediction)
    if use_prediction:
        for bi in range(nb_pred_i):
            for bj in range(nb_pred_j):
                writer.write_bits(int(mode_map[bi, bj]), 3)

    # ── 2. Blocs adaptatifs ───────────────────────────────────────
    writer.write_bool(use_adaptive_blocks)

    if use_adaptive_blocks:
        from .adaptive_blocks import compute_split_map, get_adaptive_block_list
        split_map = compute_split_map(residuals)
        nb_si, nb_sj = split_map.shape
        # Écrire la split_map (1 bit par super-bloc 16x16)
        for si in range(nb_si):
            for sj in range(nb_sj):
                writer.write_bool(bool(split_map[si, sj]))
        block_list = get_adaptive_block_list(pnl, pnc, split_map)
    else:
        block_list = []
        for bi in range(nb_bi):
            for bj in range(nb_bj):
                i0 = bi * block_size
                i1 = min(i0 + block_size, pnl)
                j0 = bj * block_size
                j1 = min(j0 + block_size, pnc)
                block_list.append((i0, i1, j0, j1))

    # ── 2. Construire les matrices sur les résidus ─────────────
    # NOTE: on ne construit PAS les matrices ici — on les construit
    # par bloc APRÈS la transformation palette pour que les indices
    # soient cohérents.

    ps = stats['plane_stats'][plane_name]

    # ══════════════════════════════════════════════════════════
    #  PHASE 1 : Classifier tous les blocs → collecter les CM
    # ══════════════════════════════════════════════════════════
    from .palette import (
        analyze_block_palette, palette_transform,
        estimate_dl_palette, write_palette,
    )
    from .matrices import build_all_matrices as _bam

    block_infos = []  # stocke la classification de chaque bloc

    for (i0, i1, j0, j1) in block_list:
        block_data = residuals[:, i0:i1, j0:j1].copy()

        # Palette
        pal_info = analyze_block_palette(block_data)
        m = pal_info['m']
        use_palette = (pal_info['index_bits'] < color_bits and m <= 64)

        if use_palette:
            effective_bits = pal_info['index_bits']
            indexed_block = palette_transform(block_data, pal_info)
            mini_plane = indexed_block.copy()
        else:
            effective_bits = color_bits
            mini_plane = block_data.copy()

        # Matrices + pixels
        data_blk = _bam(mini_plane)
        pixels = _analyze_block_pixels(
            mini_plane, data_blk, gop_r, 0, i1-i0, 0, j1-j0
        )

        # Classifier
        if heuristic is not None:
            from .heuristic import extract_block_features
            feats = extract_block_features(
                mini_plane, 0, i1-i0, 0, j1-j0, gop_r
            )
            proc_type, _ = heuristic.predict_method(feats)
            from .process_types import (
                _estimate_dl_mono, _estimate_dl_pp,
                _estimate_dl_spatial, _estimate_dl_markov_v2,
            )
            if proc_type == 0:
                _, info = _estimate_dl_mono(pixels, effective_bits)
                if info is None: proc_type = 1
            elif proc_type == 2:
                _, info = _estimate_dl_spatial(
                    pixels, gop_r, effective_bits, gop_duration_bits)
                if info is None: proc_type = 1
            elif proc_type == 3:
                _, info = _estimate_dl_markov_v2(
                    pixels, gop_r, effective_bits, gop_duration_bits)
                if info is None: proc_type = 1
            if proc_type == 1:
                _, info = _estimate_dl_pp(
                    pixels, gop_r, effective_bits, gop_duration_bits)
        else:
            proc_type, dl, info = classify_block(
                pixels, gop_r, effective_bits, gop_duration_bits
            )

        # Construire le Code Méthode
        if proc_type == 0:
            rep_code = REP_R1
        elif proc_type == 1:
            rep_code = [REP_R1, REP_R2, REP_R3, REP_R4][info['best_rep'] - 1]
        elif proc_type == 2:
            rep_code = REP_R3
        else:
            rep_code = REP_R1
        cm = make_code_methode(
            [PROC_MONO, PROC_PP, PROC_SPATIAL, PROC_MARKOV][proc_type],
            rep_code, comp_flag, col_flag
        )

        block_infos.append({
            'i0': i0, 'i1': i1, 'j0': j0, 'j1': j1,
            'use_palette': use_palette, 'pal_info': pal_info,
            'effective_bits': effective_bits,
            'pixels': pixels, 'proc_type': proc_type,
            'info': info, 'cm': cm, 'mini_plane': mini_plane,
        })

    # ══════════════════════════════════════════════════════════
    #  PHASE 1b : Construire le Huffman sur les Code Méthode
    # ══════════════════════════════════════════════════════════
    cm_freq = Counter(bi['cm'] for bi in block_infos)

    use_cm_huffman = len(cm_freq) >= 2 and len(block_infos) >= 4
    cm_htable = None

    if use_cm_huffman:
        cm_htable = HuffmanTable.from_frequencies(dict(cm_freq))
        avg_cm_bits = cm_htable.average_bits(dict(cm_freq))
        n_sym = len(cm_freq)
        overhead = n_sym * (7 + 5) + max(2 * max(n_sym.bit_length(), 1) - 1, 1)
        total_fixed = 7 * len(block_infos)
        total_huff = overhead + int(avg_cm_bits * len(block_infos))
        if total_huff >= total_fixed:
            use_cm_huffman = False
            cm_htable = None

    writer.write_bool(use_cm_huffman)
    if use_cm_huffman:
        cm_htable.write_table(writer, 7)  # CM values are 7-bit

    # ══════════════════════════════════════════════════════════
    #  PHASE 2 : Encoder tous les blocs avec CM Huffman
    # ══════════════════════════════════════════════════════════
    for bi in block_infos:
        i0, i1, j0, j1 = bi['i0'], bi['i1'], bi['j0'], bi['j1']
        proc_type = bi['proc_type']
        info = bi['info']
        pixels = bi['pixels']
        effective_bits = bi['effective_bits']
        cm = bi['cm']

        # Palette flag + data
        writer.write_bool(bi['use_palette'])
        if bi['use_palette']:
            write_palette(writer, bi['pal_info'], color_bits)

        # Code Méthode (Huffman ou fixe 7 bits)
        if use_cm_huffman:
            cm_htable.encode_symbol(writer, cm)
        else:
            writer.write_bits(cm, 7)

        # ── Données du bloc ────────────────────────────────
        if proc_type == 0:
            writer.write_bits(info['color'], effective_bits)
            n_px = len(pixels)
            stats['mono_count'] += n_px
            ps['mono'] += n_px
            stats['total_pixels_encoded'] += n_px

        elif proc_type == 1:
            best_rep = info['best_rep']
            htable, has_huff = _build_block_huffman(
                pixels, effective_bits, use_huffman
            )
            writer.write_bool(has_huff)
            if has_huff:
                htable.write_table(writer, effective_bits)

            for px in pixels:
                if best_rep == 1:
                    encode_R1(writer, px['seq'], effective_bits, htable)
                elif best_rep == 2:
                    encode_R2(writer, px['dates'], px['colors'],
                              px['n_jumps'], gop_duration_bits,
                              effective_bits, htable)
                elif best_rep == 3:
                    encode_R3(writer, px['bool_vec'], px['colors'],
                              gop_r, effective_bits, htable)
                elif best_rep == 4:
                    encode_R4(writer, px['n_jumps'], px['s_index'],
                              px['colors'], gop_r, gop_duration_bits,
                              effective_bits, htable)

                stats['rep_counts'][best_rep] += 1
                ps['reps'][best_rep] += 1
                stats['total_pixels_encoded'] += 1

        elif proc_type == 2:
            htable, has_huff = _build_block_huffman(
                pixels, effective_bits, use_huffman
            )
            writer.write_bool(has_huff)
            if has_huff:
                htable.write_table(writer, effective_bits)

            encode_spatial(writer, pixels, info, gop_r,
                           gop_duration_bits, effective_bits, htable)
            stats['total_pixels_encoded'] += len(pixels)
            if 'proc_spatial_count' not in stats:
                stats['proc_spatial_count'] = 0
            stats['proc_spatial_count'] += len(pixels)

        elif proc_type == 3:
            htable, has_huff = _build_block_huffman(
                pixels, effective_bits, use_huffman
            )
            writer.write_bool(has_huff)
            if has_huff:
                htable.write_table(writer, effective_bits)

            encode_markov_v2(writer, pixels, info, gop_r,
                             effective_bits, htable)
            stats['total_pixels_encoded'] += len(pixels)
            if 'proc_markov_count' not in stats:
                stats['proc_markov_count'] = 0
            stats['proc_markov_count'] += len(pixels)


# ═══════════════════════════════════════════════════════════════
#  DÉCODAGE
# ═══════════════════════════════════════════════════════════════

def decode_plane_blocks(
    reader: BitReader,
    buf: np.ndarray,
    pnl: int, pnc: int, gop_r: int,
    t_offset: int, r_total: int,
    color_bits: int,
    block_size: int,
    stats: dict,
) -> None:
    gop_duration_bits = max(1, ceil(log2(max(gop_r, 2))))
    nb_bi = ceil(pnl / block_size)
    nb_bj = ceil(pnc / block_size)

    # ── 1. Lire les modes de prédiction (toujours sur grille 8x8) ──
    pred_bs = 8
    nb_pred_i = ceil(pnl / pred_bs)
    nb_pred_j = ceil(pnc / pred_bs)
    has_prediction = reader.read_bool()
    mode_map = np.zeros((nb_pred_i, nb_pred_j), dtype=np.int32)
    if has_prediction:
        for bi in range(nb_pred_i):
            for bj in range(nb_pred_j):
                mode_map[bi, bj] = reader.read_bits(3)

    # ── 2. Lire la split_map si blocs adaptatifs ───────────────────
    has_adaptive = reader.read_bool()
    if has_adaptive:
        from .adaptive_blocks import get_adaptive_block_list
        nb_si = ceil(pnl / 16)
        nb_sj = ceil(pnc / 16)
        split_map = np.zeros((nb_si, nb_sj), dtype=bool)
        for si in range(nb_si):
            for sj in range(nb_sj):
                split_map[si, sj] = reader.read_bool()
        block_list = get_adaptive_block_list(pnl, pnc, split_map)
    else:
        block_list = []
        for bi in range(nb_bi):
            for bj in range(nb_bj):
                i0 = bi * block_size
                i1 = min(i0 + block_size, pnl)
                j0 = bj * block_size
                j1 = min(j0 + block_size, pnc)
                block_list.append((i0, i1, j0, j1))

    # ── 3. Lire le Huffman des Code Méthode ──────────────────────
    has_cm_huffman = reader.read_bool()
    cm_htable = None
    if has_cm_huffman:
        cm_htable = HuffmanTable.read_table(reader, 7)

    # ── 4. Décoder les résidus ─────────────────────────────────────
    res_buf = np.zeros((gop_r, pnl, pnc), dtype=np.uint8)

    for (i0, i1, j0, j1) in block_list:
            n_pixels = (i1 - i0) * (j1 - j0)

            # ── Palette ────────────────────────────────
            from .palette import read_palette, inverse_palette_transform
            has_palette = reader.read_bool()
            pal_info = None
            if has_palette:
                pal_info = read_palette(reader, color_bits)
                eff_bits = pal_info['index_bits']
            else:
                eff_bits = color_bits

            # Code Méthode (Huffman ou fixe 7 bits)
            if has_cm_huffman:
                cm = cm_htable.decode_symbol(reader)
            else:
                cm = reader.read_bits(7)
            proc, rep, comp, col = parse_code_methode(cm)

            # ── PROC_MONO ──────────────────────────────
            if proc == PROC_MONO:
                color = reader.read_bits(eff_bits)
                res_buf[:, i0:i1, j0:j1] = color
                stats['mono_count'] += n_pixels

            # ── PROC_PP ────────────────────────────────
            elif proc == PROC_PP:
                has_huff = reader.read_bool()
                htable = None
                if has_huff:
                    htable = HuffmanTable.read_table(reader, eff_bits)

                for i in range(i0, i1):
                    for j in range(j0, j1):
                        if rep == REP_R1:
                            seq = decode_R1(reader, gop_r, eff_bits, htable)
                            stats['rep_counts'][1] += 1
                        elif rep == REP_R2:
                            seq = decode_R2(reader, gop_r, gop_duration_bits,
                                            eff_bits, htable)
                            stats['rep_counts'][2] += 1
                        elif rep == REP_R3:
                            seq = decode_R3(reader, gop_r, eff_bits, htable)
                            stats['rep_counts'][3] += 1
                        elif rep == REP_R4:
                            seq = decode_R4(reader, gop_r, gop_duration_bits,
                                            eff_bits, htable)
                            stats['rep_counts'][4] += 1
                        for t in range(gop_r):
                            res_buf[t, i, j] = seq[t]

            # ── PROC_SPATIAL ───────────────────────────
            elif proc == PROC_SPATIAL:
                has_huff = reader.read_bool()
                htable = None
                if has_huff:
                    htable = HuffmanTable.read_table(reader, eff_bits)
                sequences = decode_spatial(
                    reader, gop_r, gop_duration_bits,
                    eff_bits, n_pixels, htable,
                )
                px_idx = 0
                for i in range(i0, i1):
                    for j in range(j0, j1):
                        for t in range(gop_r):
                            res_buf[t, i, j] = sequences[px_idx][t]
                        px_idx += 1

            # ── PROC_MARKOV ────────────────────────────
            elif proc == PROC_MARKOV:
                has_huff = reader.read_bool()
                htable = None
                if has_huff:
                    htable = HuffmanTable.read_table(reader, eff_bits)
                sequences = decode_markov(
                    reader, gop_r, eff_bits, n_pixels, htable,
                )
                px_idx = 0
                for i in range(i0, i1):
                    for j in range(j0, j1):
                        for t in range(gop_r):
                            res_buf[t, i, j] = sequences[px_idx][t]
                        px_idx += 1

            # ── Inverse palette ────────────────────────
            if has_palette and pal_info is not None:
                block_decoded = res_buf[:, i0:i1, j0:j1].copy()
                res_buf[:, i0:i1, j0:j1] = inverse_palette_transform(
                    block_decoded, pal_info
                )

    # ── 4. Inverser la prédiction (toujours sur grille 8x8) ─────
    if has_prediction:
        gop_reconstructed = invert_prediction_by_blocks(
            res_buf, mode_map, pred_bs
        )
    else:
        gop_reconstructed = res_buf

    # Copier dans le buffer de sortie
    for t in range(gop_r):
        t_abs = t_offset + t
        if t_abs < r_total:
            buf[t_abs, :pnl, :pnc] = gop_reconstructed[t]
