"""
Prediction — Prédiction spatiale intra-frame.

8 modes de prédiction par bloc (6 actifs) :
  Mode 0 : Bypass        — pas de prédiction (valeur brute)
  Mode 1 : Left          — pixel[i][j-1]
  Mode 2 : Top           — pixel[i-1][j]
  Mode 3 : DC            — (left + top) // 2
  Mode 4 : Paeth (PNG)   — left+top-topleft, puis closest(left,top,topleft)
  Mode 5 : MED (JPEG-LS) — median edge-detecting

Le mode est choisi par bloc en estimant l'entropie des résidus.
Le mode coûte 3 bits par bloc dans le bitstream (6 modes → 3 bits).

Résidu modulo 256 :
  encode : residual = (value - prediction) & 0xFF
  decode : value    = (residual + prediction) & 0xFF
"""

import numpy as np
from typing import Tuple
from math import log2
from collections import Counter


# ── Modes ──────────────────────────────────────────────────────

PRED_BYPASS = 0
PRED_LEFT   = 1
PRED_TOP    = 2
PRED_DC     = 3
PRED_PAETH  = 4
PRED_MED    = 5

PRED_NAMES = {0: "Bypass", 1: "Left", 2: "Top", 3: "DC",
              4: "Paeth", 5: "MED"}
NUM_PRED_MODES = 6
PRED_MODE_BITS = 3  # ceil(log2(6)) = 3


# ═══════════════════════════════════════════════════════════════
#  APPLICATION DE LA PRÉDICTION (ENCODEUR)
# ═══════════════════════════════════════════════════════════════

def apply_prediction_frame(frame: np.ndarray, mode: int) -> np.ndarray:
    """
    Applique la prédiction à une frame et retourne les résidus.

    Paeth et MED nécessitent un scan séquentiel car la prédiction
    dépend du pixel topleft qui est déjà reconstruit. Pour l'encodeur
    on peut utiliser les valeurs originales car frame est l'original.
    """
    if mode == PRED_BYPASS:
        return frame.copy()

    nl, nc = frame.shape
    f = frame.astype(np.int32)

    if mode == PRED_LEFT:
        pred = np.zeros((nl, nc), dtype=np.int32)
        pred[:, 1:] = f[:, :-1]

    elif mode == PRED_TOP:
        pred = np.zeros((nl, nc), dtype=np.int32)
        pred[1:, :] = f[:-1, :]

    elif mode == PRED_DC:
        left = np.zeros((nl, nc), dtype=np.int32)
        left[:, 1:] = f[:, :-1]
        top = np.zeros((nl, nc), dtype=np.int32)
        top[1:, :] = f[:-1, :]
        pred = (left + top) >> 1

    elif mode == PRED_PAETH:
        # Paeth : p = left + top - topleft
        # predict = closest(left, top, topleft) to p
        left = np.zeros((nl, nc), dtype=np.int32)
        left[:, 1:] = f[:, :-1]
        top = np.zeros((nl, nc), dtype=np.int32)
        top[1:, :] = f[:-1, :]
        topleft = np.zeros((nl, nc), dtype=np.int32)
        topleft[1:, 1:] = f[:-1, :-1]

        p = left + top - topleft
        pa = np.abs(p - left)
        pb = np.abs(p - top)
        pc = np.abs(p - topleft)

        pred = np.where(
            (pa <= pb) & (pa <= pc), left,
            np.where(pb <= pc, top, topleft)
        )

    elif mode == PRED_MED:
        # MED (JPEG-LS) :
        #   if topleft >= max(left, top): predict = min(left, top)
        #   elif topleft <= min(left, top): predict = max(left, top)
        #   else: predict = left + top - topleft
        left = np.zeros((nl, nc), dtype=np.int32)
        left[:, 1:] = f[:, :-1]
        top = np.zeros((nl, nc), dtype=np.int32)
        top[1:, :] = f[:-1, :]
        topleft = np.zeros((nl, nc), dtype=np.int32)
        topleft[1:, 1:] = f[:-1, :-1]

        mn = np.minimum(left, top)
        mx = np.maximum(left, top)
        pred = np.where(
            topleft >= mx, mn,
            np.where(topleft <= mn, mx, left + top - topleft)
        )

    else:
        pred = np.zeros((nl, nc), dtype=np.int32)

    residuals = (f - pred) & 0xFF
    return residuals.astype(np.uint8)


def invert_prediction_frame(residuals: np.ndarray, mode: int) -> np.ndarray:
    """
    Inverse la prédiction : reconstruit la frame depuis les résidus.
    Pixel par pixel (raster scan) car la prédiction dépend des pixels reconstruits.
    """
    if mode == PRED_BYPASS:
        return residuals.copy()

    nl, nc = residuals.shape
    frame = np.zeros((nl, nc), dtype=np.uint8)

    for i in range(nl):
        for j in range(nc):
            left = int(frame[i, j - 1]) if j > 0 else 0
            top = int(frame[i - 1, j]) if i > 0 else 0
            topleft = int(frame[i - 1, j - 1]) if (i > 0 and j > 0) else 0

            if mode == PRED_LEFT:
                pred = left
            elif mode == PRED_TOP:
                pred = top
            elif mode == PRED_DC:
                pred = (left + top) >> 1
            elif mode == PRED_PAETH:
                p = left + top - topleft
                pa = abs(p - left)
                pb = abs(p - top)
                pc = abs(p - topleft)
                if pa <= pb and pa <= pc:
                    pred = left
                elif pb <= pc:
                    pred = top
                else:
                    pred = topleft
            elif mode == PRED_MED:
                mn = min(left, top)
                mx = max(left, top)
                if topleft >= mx:
                    pred = mn
                elif topleft <= mn:
                    pred = mx
                else:
                    pred = left + top - topleft
            else:
                pred = 0

            frame[i, j] = (int(residuals[i, j]) + pred) & 0xFF

    return frame


# ═══════════════════════════════════════════════════════════════
#  APPLICATION SUR UN GOP COMPLET
# ═══════════════════════════════════════════════════════════════

def apply_prediction_gop(
    gop: np.ndarray,
    mode: int,
) -> np.ndarray:
    """
    Applique la prédiction frame par frame sur un GOP.

    Args:
        gop: shape (gop_r, nl, nc), dtype uint8
        mode: mode de prédiction

    Returns:
        residuals_gop: shape (gop_r, nl, nc), dtype uint8
    """
    gop_r = gop.shape[0]
    residuals = np.zeros_like(gop)

    for t in range(gop_r):
        residuals[t] = apply_prediction_frame(gop[t], mode)

    return residuals


def invert_prediction_gop(
    residuals_gop: np.ndarray,
    mode: int,
) -> np.ndarray:
    """
    Inverse la prédiction sur un GOP complet.
    """
    gop_r = residuals_gop.shape[0]
    gop = np.zeros_like(residuals_gop)

    for t in range(gop_r):
        gop[t] = invert_prediction_frame(residuals_gop[t], mode)

    return gop


# ═══════════════════════════════════════════════════════════════
#  CHOIX DU MODE OPTIMAL
# ═══════════════════════════════════════════════════════════════

def _estimate_entropy(data: np.ndarray) -> float:
    """Estime l'entropie de Shannon en bits/symbole."""
    flat = data.flatten()
    n = len(flat)
    if n == 0:
        return 8.0
    counts = Counter(flat.tolist())
    entropy = 0.0
    for c in counts.values():
        p = c / n
        if p > 0:
            entropy -= p * log2(p)
    return entropy


def choose_best_mode(
    gop: np.ndarray,
    block_i0: int, block_i1: int,
    block_j0: int, block_j1: int,
) -> Tuple[int, float]:
    """
    Choisit le mode de prédiction optimal pour un bloc.

    Extrait la zone [i0:i1, j0:j1] de chaque frame, applique chaque
    mode de prédiction, mesure l'entropie des résidus, et retourne
    le mode avec l'entropie la plus basse.

    Args:
        gop: shape (gop_r, nl, nc)
        block_i0..j1: coordonnées du bloc

    Returns:
        (best_mode, best_entropy)
    """
    gop_r = gop.shape[0]
    block = gop[:, block_i0:block_i1, block_j0:block_j1].copy()

    best_mode = PRED_BYPASS
    best_entropy = 8.0  # pire cas

    for mode in range(NUM_PRED_MODES):
        # Appliquer la prédiction sur le sous-bloc
        # Note : pour Left/Top, les prédictions aux bords du bloc
        # utilisent 0 (pas les pixels voisins hors bloc).
        # C'est une simplification — en H.264, on utiliserait les
        # vrais voisins. Ici ça suffit pour l'estimation MDL.
        residuals = np.zeros_like(block)
        for t in range(gop_r):
            residuals[t] = apply_prediction_frame(block[t], mode)

        ent = _estimate_entropy(residuals)
        if ent < best_entropy:
            best_entropy = ent
            best_mode = mode

    return best_mode, best_entropy


def choose_best_mode_plane(
    gop: np.ndarray,
    block_size: int,
) -> np.ndarray:
    """
    Choisit le mode optimal pour chaque bloc du plan.

    Returns:
        mode_map: shape (nb_blocks_i, nb_blocks_j), dtype int
    """
    from math import ceil
    gop_r, nl, nc = gop.shape
    nb_bi = ceil(nl / block_size)
    nb_bj = ceil(nc / block_size)

    mode_map = np.zeros((nb_bi, nb_bj), dtype=np.int32)

    for bi in range(nb_bi):
        for bj in range(nb_bj):
            i0 = bi * block_size
            i1 = min(i0 + block_size, nl)
            j0 = bj * block_size
            j1 = min(j0 + block_size, nc)

            mode, _ = choose_best_mode(gop, i0, i1, j0, j1)
            mode_map[bi, bj] = mode

    return mode_map


def apply_prediction_by_blocks(
    gop: np.ndarray,
    mode_map: np.ndarray,
    block_size: int,
) -> np.ndarray:
    """
    Applique la prédiction bloc par bloc avec le mode choisi.

    Returns:
        residuals: shape (gop_r, nl, nc)
    """
    from math import ceil
    gop_r, nl, nc = gop.shape
    nb_bi = ceil(nl / block_size)
    nb_bj = ceil(nc / block_size)

    residuals = np.zeros_like(gop)

    for bi in range(nb_bi):
        for bj in range(nb_bj):
            i0 = bi * block_size
            i1 = min(i0 + block_size, nl)
            j0 = bj * block_size
            j1 = min(j0 + block_size, nc)

            mode = int(mode_map[bi, bj])
            block = gop[:, i0:i1, j0:j1]

            for t in range(gop_r):
                residuals[t, i0:i1, j0:j1] = apply_prediction_frame(
                    block[t], mode
                )

    return residuals


def invert_prediction_by_blocks(
    residuals: np.ndarray,
    mode_map: np.ndarray,
    block_size: int,
) -> np.ndarray:
    """
    Inverse la prédiction bloc par bloc.
    """
    from math import ceil
    gop_r, nl, nc = residuals.shape
    nb_bi = ceil(nl / block_size)
    nb_bj = ceil(nc / block_size)

    gop = np.zeros_like(residuals)

    for bi in range(nb_bi):
        for bj in range(nb_bj):
            i0 = bi * block_size
            i1 = min(i0 + block_size, nl)
            j0 = bj * block_size
            j1 = min(j0 + block_size, nc)

            mode = int(mode_map[bi, bj])
            block_res = residuals[:, i0:i1, j0:j1]

            for t in range(gop_r):
                gop[t, i0:i1, j0:j1] = invert_prediction_frame(
                    block_res[t], mode
                )

    return gop
